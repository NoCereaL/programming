package presentation;

import business.FYPSystem;
import database.FYPDatabase;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;

/**
 * Class for holding and creating all GUI components.
 */
public class FYPGUI extends JFrame {

    /**
     * {@code JList} for selecting search results.
     */
    protected JList<String> lstResults;

    /**
     * {@code JTextArea} for printing alerts and file contents for the user to view.
     */
    protected JTextArea txtReader;

    /**
     * A value for clear Module Coordinator role identification.
     */
    public final static int MC_GUI = 1;

    /**
     * A value for clear Project Supervisor role identification.
     */
    public final static int PS_GUI = 2;

    /**
     * A value for clear Student role identification.
     */
    public final static int S_GUI = 3;

    /**
     * An action listener given by the {@link GUIInputHandler}. Will handle button presses.
     */
    protected ActionListener al;

    /**
     * A mouse listener given by the {@link GUIInputHandler}. Will handle interaction with {@link #lstResults}.
     */
    protected MouseListener ml;

    /**
     * {@code JTextField} for taking search queries from the user.
     */
    protected JTextField txtSearch;

    /**
     * {@code JTextField} for taking login info.
     */
    protected JTextField txtUsername;

    /**
     * {@code JPasswordField} for taking login info.
     */
    protected JPasswordField txtPassword;

    /**
     * {@code JButton} which calls a function from {@code FYPSystem}.
     */
    protected JButton btnSearch, btnOpenFile, btnAssignProjects, btnCloseFiles, btnEdit, btnSaveChanges, btnLogin, btnAddUser;

    /**
     * {@code JComboBox} for taking which file the user wants to open.
     */
    protected JComboBox<String> cmbFileToOpen;

    /**
     * {@code JComboBox} for taking which user the module coordinator wants to create.
     */
    protected JComboBox<String> cmbUser;

    /**
     * {@code JFileChooser} for opening and saving files.
     */
    protected JFileChooser fc;

    /**
     * The content pane of the main GUI frame. Used to add panels to the frame.
     */
    protected Container contentPane;

    /**
     * The layout of the main GUI frame. Used to switch between login and user-specific panels.
     */
    protected CardLayout cardLayout;

    /**
     * A {@code ScrollPane} which displays results from user searches. Contains the {@link #lstResults}.
     */
    protected JScrollPane scrPaneResults;

    /**
     * A {@code ScrollPane} which displays text from user files. Contains the {@link #txtReader}.
     */
    protected JScrollPane scrPaneReader;

    /**
     * Constructor for {@code FYPGUI}. Builds frame and adds login components using {@code CardLayout}.
     */
    public FYPGUI() {
        setMinimumSize(new Dimension(800, 400));
        //setResizable(false);
        setTitle("Final Year Project Assignment System");

        cardLayout = new CardLayout();

        contentPane = this.getContentPane();
        contentPane.setLayout(cardLayout);

        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lblUName = new JLabel("Username: ");
        JLabel lblPass = new JLabel("Password: ");
        txtPassword = new JPasswordField(12);
        txtUsername = new JTextField(12);
        btnLogin = new JButton("Login");

        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        loginPanel.add(lblUName, gbc);

        gbc.gridy = 0;
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        loginPanel.add(txtUsername, gbc);

        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        loginPanel.add(lblPass, gbc);

        gbc.gridy = 1;
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        loginPanel.add(txtPassword, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        loginPanel.add(btnLogin, gbc);

        contentPane.add(loginPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);
        setVisible(true);

    }

    /**
     * Method for initialising the specific user GUI depending on entered login details.
     * @param role An {@code int} determined from the {@link FYPSystem#checkLogin(String, String)} method.
     * @param i An instance of {@link FYPGUI}.
     */
    public void initGUI(int role, FYPGUI i) {
        if(role == MC_GUI) {
            //initialises MCGUI panel to be added to GUI frame
            JPanel mcPanel = new MCGUI(ml, al, i);
            //removes focusability from login panel button (may need more setFocusable(false) when more components are added!)
            i.btnLogin.setFocusable(false);
            //adds panel to the main GUI frame's content pane
            contentPane.add(mcPanel);
            //switches user view to the new MCGUI panel
            cardLayout.next(contentPane);
            //sets focus to the new panel
            mcPanel.requestFocusInWindow(); //use requestFocusInWindow as requestFocus can behave differently on certain systems.
        } else if(role == PS_GUI) {
            //code for initialising Project Supervisor GUI
            JPanel psPanel = new PSGUI(al, i);
            i.btnLogin.setFocusable(false);
            //adds panel to the main GUI frame's content pane
            contentPane.add(psPanel);
            //switches user view to the new PSGUI panel
            cardLayout.next(contentPane);
            //sets focus to the new panel
            psPanel.requestFocusInWindow(); //use requestFocusInWindow as requestFocus can behave differently on certain systems.
        } else if(role == S_GUI) {
            //code for initialising Student GUI
            JPanel sPanel = new SGUI(al, i);
            i.btnLogin.setFocusable(false);
            //adds panel to the main GUI frame's content pane
            contentPane.add(sPanel);
            //switches user view to the new SGUI panel
            cardLayout.next(contentPane);
            //sets focus to the new panel
            sPanel.requestFocusInWindow(); //use requestFocusInWindow as requestFocus can behave differently on certain systems.
        } else {
            failedLogin();
        }
    }

    /**
     * Method in {@link FYPGUI} for adding event listeners to frame and login components
     *
     * @param i An instance of {@link GUIInputHandler}.
     */
    public void initListeners(GUIInputHandler i) {
        al = i;
        ml = i.lstHandler;

        btnLogin.addActionListener(i);
        this.addWindowListener(i.wndHandler);
    }

    /**
     * Method for opening the {@code JFileChooser}'s open dialogue. Users can select text files only.
     *
     * @return Returns a {@code File} if the user selected one in the {@code JFileChooser}. Returns {@code null} if not.
     * Be aware that this method can return an empty {@code File} object if the file the user selects does not exist.
     */
    public File txtFileChoose() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT Files", "txt");
        fc.setFileFilter(filter);
        int option = fc.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            return fc.getSelectedFile();
        } else {
            return null;
        }

    }

    /**
     * Method for opening the {@code JFileChooser}'s open dialogue. Users can select binary .dat files only.
     *
     * @return Returns a {@code File} if the user selected one in the {@code JFileChooser}. Returns {@code null} if not.
     * Be aware that this method can return an empty {@code File} object if the file the user selects does not exist.
     */
    public File datFileChoose() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("DAT Files", "dat");
        fc.setFileFilter(filter);
        int option = fc.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            return fc.getSelectedFile();
        } else {
            return null;
        }
    }

    /**
     * Method for saving a .dat or .txt {@code File}. Opens the {@code JFileChooser}'s save dialogue. Users can select binary
     * .dat and .txt files only.
     * @return Returns a {@code File} if the user selected one in the {@code JFileChooser}. Returns {@code null} if not.
     * Be aware that this method can return an empty {@code File} object if the file the user selects does not exist.
     * In such cases, the {@code File} should be created using {@link File#createNewFile()}.
     */
    public File fileSave() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("DAT & TXT Files", "dat", "txt");
        fc.setFileFilter(filter);
        int option = fc.showSaveDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            return fc.getSelectedFile();
        } else {
            return null;
        }
    }

    /**
     * Method for opening the editing dialogue. Takes user input for editing student scores or adding a project
     * depending on which GUI class is initialised after the login here {@link #initGUI(int, FYPGUI)}.
     * @param src The {@code JButton} whose action called this method.
     * @return Null if the user entered non-numeric characters, or numeric characters exceeding the 0-100 limits.
     * Otherwise returns a {@code String} parsable to {@code int}.
     */
    protected String openEditDialogue(JButton src) {

        if(src.getText().equals("Edit Score")) {
            String edString = JOptionPane.showInputDialog("Enter a number from 0-100");


            try {
                if (Integer.parseInt(edString) < 0 || Integer.parseInt(edString) > 100) {
                    edString = null;
                }
            } catch (NumberFormatException e) {
                edString = null;
            }

            return edString;
        } else if (src.getText().equals("Add Project")) {
            String edString = JOptionPane.showInputDialog("Enter a new project name");

            return edString;
        }

        return null;
    }

    /**
     * A method for taking Module Coordinator input to add new user details.
     * @param role The role the Module Coordinator specified for the new user.
     * @return An array containing the new user's username and password. Validation occurs in the system layer.
     */
    protected String[] openEditDialogue(int role) {

        String userString = JOptionPane.showInputDialog("Enter a new user name");
        String passString = JOptionPane.showInputDialog("Enter a new password");

        String[] usernamePassword = {userString, passString};

        return usernamePassword;

    }

    /**
     * Method for printing search results to {@link #lstResults}.
     * @param a An {@code ArrayList<String>}.
     */
    public void printResults (ArrayList<String> a) {
        String[] tmp = a.toArray(new String[a.size()]);
        this.lstResults.setListData(tmp);
    }

    /**
     * Method for printing a single {@code String} to the {@link #txtReader}.
     * @param s A {@code String}.
     */
    public void printToReader (String s) {
        this.txtReader.append(s);
    }

    /**
     * Method for printing the contents of an {@code ArrayList<String>} to the {@link #txtReader}.
     * @param a An {@code ArrayList<String>}.
     */
    public void printToReader (ArrayList<String> a) {
        for(int i = 0; i < a.size(); i++) {
            this.txtReader.append(a.get(i)+"\n");
        }
    }

    /**
     * Method for clearing the {@link #txtReader} of text.
     */
    public void clearReader() {
        this.txtReader.setText("");
    }

    /**
     * Method for showing an option dialogue for user confirmation of overwriting a file.
     * @return A boolean value. True on clicking the 'Yes' option, false otherwise.
     */
    public boolean fileOverwrite() {
        int option = JOptionPane.showOptionDialog(this, "Do you want to overwrite the file?", "Overwrite?",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);

        if(option==JOptionPane.YES_OPTION) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method for creating a message informing the user of invalid login credentials.
     */
    private void failedLogin() {
        JLabel failed = new JLabel("These credentials do not match any on record.");
        JPanel loginPanel = (JPanel)getContentPane().getComponent(0);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.BOTH;

        if(loginPanel.getComponentCount()>5){
            loginPanel.remove(loginPanel.getComponent(loginPanel.getComponentCount()-1));
            loginPanel.add(failed, gbc);
            loginPanel.revalidate();
            loginPanel.repaint();
        }else {
            loginPanel.add(failed, gbc);
            loginPanel.revalidate();
            loginPanel.repaint();
        }
    }

    //placeholder Launcher
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                FYPGUI gui = new FYPGUI();
                FYPDatabase db = new FYPDatabase();
                FYPSystem sys = new FYPSystem(gui, db);
                GUIInputHandler inHandler = new GUIInputHandler(sys, gui);
                gui.initListeners(inHandler);
            }
        });
    }

}

/**
 * An extension of {@code JPanel} used to initialise the Module Coordinator GUI. Must initialise:<br />
 * {@link FYPGUI#fc}<br />
 * {@link FYPGUI#txtSearch}<br />
 * {@link FYPGUI#btnSearch}<br />
 * {@link FYPGUI#btnOpenFile}<br />
 * {@link FYPGUI#btnAssignProjects}<br />
 * {@link FYPGUI#lstResults}<br />
 * {@link FYPGUI#txtReader}<br />
 * {@link FYPGUI#cmbFileToOpen}<br />
 * {@link FYPGUI#btnCloseFiles}<br />
 * {@link FYPGUI#btnEdit}<br />
 * {@link FYPGUI#btnAddUser}<br />
 * {@link FYPGUI#btnSaveChanges}<br />
 * {@link FYPGUI#scrPaneResults}<br />
 * {@link FYPGUI#scrPaneReader}<br />
 * {@link FYPGUI#cmbUser}
 */
class MCGUI extends JPanel {

    public MCGUI(MouseListener ml, ActionListener al, FYPGUI i) {

        setLayout(new GridBagLayout());
        i.fc = new JFileChooser();
        JPanel pnlWest = new JPanel(new GridBagLayout());
        JPanel pnlEast = new JPanel(new GridBagLayout());
        JPanel pnlNorth = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        i.txtSearch = new JTextField();
        i.btnSearch = new JButton("Search");
        i.btnOpenFile = new JButton("Open...");
        i.btnAssignProjects = new JButton("Assign Projects");
        i.lstResults = new JList<>();
        i.txtReader = new JTextArea(10, 10);
        i.cmbFileToOpen = new JComboBox<>();
        i.cmbUser = new JComboBox<>();
        i.btnCloseFiles = new JButton("Close Files");
        i.btnEdit = new JButton("Edit Score");
        i.btnAddUser = new JButton("Add User");
        i.btnSaveChanges = new JButton("Save Changes");
        i.scrPaneResults = new JScrollPane(i.lstResults);
        i.scrPaneReader = new JScrollPane(i.txtReader);
        i.scrPaneReader.setPreferredSize(new Dimension(290, 200));
        i.scrPaneResults.setPreferredSize(new Dimension(290, 200));
        i.scrPaneReader.setMinimumSize(new Dimension(280, 190));
        i.scrPaneResults.setMinimumSize(new Dimension(280, 190));

        i.cmbFileToOpen.addItem("students");
        i.cmbFileToOpen.addItem("projects");
        i.cmbFileToOpen.addItem("students-projects");
        i.cmbUser.addItem("Student");
        i.cmbUser.addItem("Supervisor");

        i.lstResults.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        i.txtReader.setLineWrap(false);
        i.txtReader.setEditable(false);

//        pnlWest.setBackground(new Color(205, 120, 120, 255));
//        pnlEast.setBackground(new Color(157, 221, 232, 255));

        pnlWest.setPreferredSize(new Dimension(300, 350));
        pnlEast.setPreferredSize(new Dimension(300, 350));
        pnlWest.setMinimumSize(new Dimension(280, 330));
        pnlEast.setMinimumSize(new Dimension(280, 330));
        pnlNorth.setPreferredSize(new Dimension(580, 50));
        pnlNorth.setMinimumSize(new Dimension(570, 49));

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(pnlWest, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        add(pnlEast, gbc);

        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weighty = 0.01;
        gbc.insets = new Insets(5, 5, 5, 5);
        add(pnlNorth, gbc);

        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.weighty = 1;
        pnlEast.add(i.scrPaneResults, gbc);

        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 0.01;
        gbc.gridwidth = 1;
        //gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        i.txtSearch.setPreferredSize(new Dimension(200, 20));
        i.txtSearch.setMaximumSize(new Dimension(200, 20));
        i.txtSearch.setMinimumSize(new Dimension(100, 20));
        pnlEast.add(i.txtSearch, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0;
        gbc.weighty = 0.01;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        //gbc.insets = new Insets(0, 10, 0, 0);
        pnlEast.add(i.btnSearch, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);
        pnlWest.add(i.scrPaneReader, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 0;
        gbc.weighty = 0.01;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        pnlEast.add(i.btnEdit, gbc);

        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_START;
        pnlEast.add(i.btnSaveChanges, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        //gbc.anchor = GridBagConstraints.CENTER;
        pnlWest.add(i.btnOpenFile, gbc);

        gbc.gridy = 2;
        pnlWest.add(i.btnCloseFiles, gbc);

        gbc.gridy = 1;
        gbc.gridx = 1;
        pnlWest.add(i.cmbFileToOpen, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 5, 0, 0);
        pnlWest.add(i.btnAssignProjects, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0,0,0,0);
        pnlNorth.add(i.btnAddUser);
        gbc.gridx = 1;
        pnlNorth.add(i.cmbUser);

        i.btnSearch.addActionListener(al);
        i.btnAssignProjects.addActionListener(al);
        i.btnOpenFile.addActionListener(al);
        i.btnCloseFiles.addActionListener(al);
        i.btnEdit.addActionListener(al);
        i.btnAddUser.addActionListener(al);
        i.btnSaveChanges.addActionListener(al);

        i.lstResults.addMouseListener(ml);
        i.cmbFileToOpen.setSelectedIndex(0);
        i.cmbUser.setSelectedIndex(0);
    }
}

/**
 * An extension of {@code JPanel} used to initialise the Project Supervisor GUI.<br />
 *  {@link FYPGUI#fc}<br />
 *  {@link FYPGUI#btnOpenFile}<br />
 *  {@link FYPGUI#txtReader}<br />
 *  {@link FYPGUI#cmbFileToOpen}<br />
 *  {@link FYPGUI#btnCloseFiles}<br />
 *  {@link FYPGUI#btnEdit}<br />
 *  {@link FYPGUI#btnSaveChanges}<br />
 *  {@link FYPGUI#scrPaneReader}
 */
class PSGUI extends JPanel {
    public PSGUI(ActionListener al, FYPGUI i) {
        setLayout(new GridBagLayout());
        i.fc = new JFileChooser();
        JPanel pnlWest = new JPanel(new GridBagLayout());
        JPanel pnlEast = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        i.btnOpenFile = new JButton("Open...");
        i.txtReader = new JTextArea(10, 10);
        i.btnEdit = new JButton("Add Project");
        i.cmbFileToOpen = new JComboBox<>();
        i.btnCloseFiles = new JButton("Close Files");
        i.btnSaveChanges = new JButton("Save Projects");
        i.scrPaneReader = new JScrollPane(i.txtReader);
        i.scrPaneReader.setPreferredSize(new Dimension(290, 200));
        i.scrPaneReader.setMinimumSize(new Dimension(280, 190));

        i.cmbFileToOpen.addItem("projects");
        i.cmbFileToOpen.addItem("students-projects");

        i.txtReader.setLineWrap(false);
        i.txtReader.setEditable(false);

//        pnlWest.setBackground(new Color(205, 120, 120, 255));
//        pnlEast.setBackground(new Color(157, 221, 232, 255));

        pnlWest.setPreferredSize(new Dimension(300, 400));
        pnlEast.setPreferredSize(new Dimension(300, 400));
        pnlWest.setMinimumSize(new Dimension(280, 380));
        pnlEast.setMinimumSize(new Dimension(280, 380));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(pnlWest, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);
        pnlWest.add(i.scrPaneReader, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        gbc.weighty = 0.01;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.LINE_START;
        pnlWest.add(i.btnOpenFile, gbc);

        gbc.gridy = 2;
        pnlWest.add(i.btnCloseFiles, gbc);

        gbc.gridy = 1;
        gbc.gridx = 1;
        pnlWest.add(i.cmbFileToOpen, gbc);

        gbc.gridx = 2;
        pnlWest.add(i.btnEdit, gbc);

        gbc.gridy = 2;
        pnlWest.add(i.btnSaveChanges, gbc);

        i.btnOpenFile.addActionListener(al);
        i.btnCloseFiles.addActionListener(al);
        i.btnEdit.addActionListener(al);
        i.btnSaveChanges.addActionListener(al);
        i.cmbFileToOpen.setSelectedIndex(0);
    }
}

/**
 * An extension of {@code JPanel} used to initialise the Student GUI.<br />
 *  {@link FYPGUI#fc}<br />
 *  {@link FYPGUI#btnOpenFile}<br />
 *  {@link FYPGUI#txtReader}<br />
 *  {@link FYPGUI#cmbFileToOpen}<br />
 *  {@link FYPGUI#btnCloseFiles}<br />
 *  {@link FYPGUI#scrPaneReader}
 */
class SGUI extends JPanel {
    public SGUI(ActionListener al, FYPGUI i) {
        setLayout(new GridBagLayout());
        i.fc = new JFileChooser();
        JPanel pnlCenter = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        i.btnOpenFile = new JButton("Open...");
        i.txtReader = new JTextArea(10, 10);
        i.cmbFileToOpen = new JComboBox<>();
        i.btnCloseFiles = new JButton("Close Files");
        i.scrPaneReader = new JScrollPane(i.txtReader);
        i.scrPaneReader.setPreferredSize(new Dimension(290, 200));
        i.scrPaneReader.setMinimumSize(new Dimension(280, 190));

        i.cmbFileToOpen.addItem("projects");
        i.cmbFileToOpen.addItem("students-projects");

        i.txtReader.setLineWrap(false);
        i.txtReader.setEditable(false);

//        pnlWest.setBackground(new Color(205, 120, 120, 255));
//        pnlEast.setBackground(new Color(157, 221, 232, 255));

        pnlCenter.setPreferredSize(new Dimension(790, 390));
        pnlCenter.setMinimumSize(new Dimension(780, 380));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(pnlCenter, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);
        pnlCenter.add(i.scrPaneReader, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0.1;
        gbc.weighty = 0.1;
        gbc.fill = GridBagConstraints.NONE;
        //gbc.anchor = GridBagConstraints.CENTER;
        pnlCenter.add(i.btnOpenFile, gbc);

        gbc.gridy = 2;
        pnlCenter.add(i.btnCloseFiles, gbc);

        gbc.gridy = 1;
        gbc.gridx = 1;
        pnlCenter.add(i.cmbFileToOpen, gbc);

        i.btnOpenFile.addActionListener(al);
        i.btnCloseFiles.addActionListener(al);
        i.cmbFileToOpen.setSelectedIndex(0);
    }
}