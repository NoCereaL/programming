package presentation;

import business.FYPSystem;

import java.awt.event.*;

/**
 * Class for holding all the GUI components' event listeners.
 */
public class GUIInputHandler implements ActionListener {

    /**
     * {@code FYPSystem} to enable communication between layers.
     */
    FYPSystem sys;

    /**
     * {@code FYPGUI} to enable communication between layers.
     */
    FYPGUI gui;

    /**
     * Stores currently selected list item.
     */
    private String lstItem;

    /**
     * Constructor for {@code GUIInputHandler}. Initialises {@link #sys} attribute and {@link #gui} attribute.
     * @param initSys An instance of {@code FYPSystem}.
     * @param initGUI An instance of {@code FYPGUI}.
     */
    public GUIInputHandler(FYPSystem initSys, FYPGUI initGUI) {
        sys = initSys;
        gui = initGUI;
    }

    /**
     * {@code ActionEvent} handler for all the GUI {@code JButtons}.
     * @param e An {@code ActionEvent} from one of the GUI {@code JButtons}.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Open...":

                switch(gui.cmbFileToOpen.getItemAt(gui.cmbFileToOpen.getSelectedIndex())) {
                    case "students":
                        sys.getStudents();
                        break;
                    case "projects":
                        sys.getProjects();
                        break;
                    case "students-projects":
                        sys.getAssigned();
                        break;
                    default:
                        break;
                }

                break;
            case "Search":
                sys.searchAssigned(gui.txtSearch.getText());
                break;
            case "Assign Projects":
                sys.assignProjects();
                break;
            case "Close Files":
                sys.dbClose();
                lstItem = null;         //setting this to null avoids possible NullPointerException inside FYPSystem.editScore().
                break;
            case "Edit Score":
                sys.editScore(lstItem, gui.openEditDialogue(gui.btnEdit));
                break;
            case "Add Project":
                sys.addProject(gui.openEditDialogue(gui.btnEdit));
                break;
            case "Add User":
                switch(gui.cmbUser.getItemAt(gui.cmbUser.getSelectedIndex())) {
                    case "Student":
                        sys.addUser(gui.openEditDialogue(3), 3);
                        break;
                    case "Supervisor":
                        sys.addUser(gui.openEditDialogue(2), 2);
                        break;
                    default:
                        break;
                }
                break;
            case "Save Changes":
                sys.saveChanges();
                break;
            case "Save Projects":
                sys.saveProjects();
                break;
            case "Login":
                sys.checkLogin(gui.txtUsername.getText(), gui.txtPassword.getText());
                break;
            default:
                break;
        }
    }

    /**
     * The input handler for the {@code JList} in the Module Coordinator GUI.
     */
    MouseListener lstHandler = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            if(gui.lstResults.getModel().getSize()>0) {
                lstItem = gui.lstResults.getModel().getElementAt(gui.lstResults.getSelectedIndex());
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    };

    /**
     * A {@code WindowListener} for the GUI. Will automatically tell the system to close any open files and connections on closing the
     * window.
     */
    WindowListener wndHandler = new WindowListener() {
        @Override
        public void windowOpened(WindowEvent e) {

        }

        @Override
        public void windowClosing(WindowEvent e) {
            sys.dbClose();
        }

        @Override
        public void windowClosed(WindowEvent e) {

        }

        @Override
        public void windowIconified(WindowEvent e) {

        }

        @Override
        public void windowDeiconified(WindowEvent e) {

        }

        @Override
        public void windowActivated(WindowEvent e) {

        }

        @Override
        public void windowDeactivated(WindowEvent e) {

        }
    };

}
