package database;

import java.io.*;
import java.sql.*;
import java.util.*;

/**
 * Class for handling data. Opens readers/writers and closes them. Opens SQL Connections and closes them.
 */
public class FYPDatabase {

    /**
     * {@code BufferedReader} for reading text files.
     */
    private BufferedReader studentsReader, projectsReader;

    /**
     * {@code BufferedWriter} for writing to text files.
     */
    private BufferedWriter txtWriter;

    /**
     * {@code ObjectInputStream} for reading students-projects binary file.
     */
    private ObjectInputStream spReader;

    /**
     * {@code ObjectOutputStream} for writing students-projects binary file.
     */
    private ObjectOutputStream spWriter;

    /**
     * {@code Connection} holding the mysql database connection.
     */
    public Connection conn;

    /**
     * Method for opening a given text file.
     * @param f A user-specified {@code File}.
     * @param fileID A {@code String} specifying which text file is to be opened. E.g. "students" or "projects".
     * @return An {@code ArrayList} of every line from the given text file.
     * @throws FileNotFoundException If the user-specified file does not exist after the initial check, this
     * exception is thrown.
     * @throws IOException If the file cannot be read.
     */
    public ArrayList<String> openTextFile(File f, String fileID) throws FileNotFoundException, IOException {
        try {

            if (!f.exists()) {
                throw new FileNotFoundException("The text file does not exist. Aborting operation.");
            } else if (!f.canRead()) {
                throw new IOException("The text file could not be read. Aborting operation.");
            }

            switch(fileID) {
                case "students":
                    studentsReader = new BufferedReader(new FileReader(f));
                    return readTextFile(studentsReader);
                case "projects":
                    projectsReader = new BufferedReader(new FileReader(f));
                    return readTextFile(projectsReader);
                default:
                    return null;
            }

        } catch (FileNotFoundException fnfe) {
            System.err.println(fnfe.getMessage());
            fnfe.printStackTrace(System.out);
            System.exit(1);
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
            ioe.printStackTrace(System.out);
            System.exit(1);
        }
        return null;
    }

    /**
     * Method for opening the students-projects binary file.
     * @param f The user-specified {@code File} to open.
     * @return A {@code HashMap} read from the students-projects file.
     * @throws FileNotFoundException When file is somehow moved/deleted after initial check in {@link business.FYPSystem}.
     * @throws IOException When the JVM is not allowed to read the file.
     */
    public HashMap<String, String> openBinFile(File f) throws FileNotFoundException, IOException {
        try {
            if (f==null) {
                throw new FileNotFoundException("The text file does not exist. Aborting operation.");
            } else if (!f.canRead()) {
                throw new IOException("The text file could not be read. Aborting operation.");
            }

            spReader = new ObjectInputStream(new FileInputStream(f));

            return readBinFile(spReader);
        } catch (FileNotFoundException fnfe) {
            System.err.println(fnfe.getMessage());
            fnfe.printStackTrace(System.out);
            System.exit(1);
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
            ioe.printStackTrace(System.out);
            System.exit(1);
        }

        return null;
    }

    /**
     * Closes all readers/writers if they are open. Also closes mysql connection.
     */
    public void closeAll() {

        //code for closing file readers & writers
        if(studentsReader!=null) {
            try {
                studentsReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(projectsReader!=null) {
            try {
                projectsReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(spReader!=null) {
            try {
                spReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(spWriter!=null) {
            try {
                spWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(conn!=null) {
            try {
                conn.close();
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
    }

    /**
     * Closes a specified reader/writer based on the given keyword.
     * @param file A {@code String} keyword to specify which reader/writer should be closed. Can be "students",
     * "projects", "sp reader" or "sp writer".
     */
    public void closeFiles(String file) {
        switch (file) {
            case "students":
                if (studentsReader != null) {
                    try {
                        studentsReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case "projects":
                if (projectsReader != null) {
                    try {
                        projectsReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case "sp reader":
                if (spReader != null) {
                    try {
                        spReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case "sp writer":
                if (spWriter != null) {
                    try {
                        spWriter.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * Method for reading a text file.
     * @param readStream A {@code BufferedReader} for the text file, produced from the
     * {@link #openTextFile(File, String)} method.
     * @return An {@code ArrayList} with the contents of the specified text file. Each entry in the {@code ArrayList}
     * is a line of the text file.
     */
    private ArrayList<String> readTextFile(BufferedReader readStream) {
        ArrayList<String> lst = new ArrayList<>();
        try {
            String text;
            while ((text = readStream.readLine()) != null){
                lst.add(text);
            }
        } catch(IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        return lst;
    }

    /**
     * Method for reading a dat file.
     * @param readStream An {@code ObjectInputStream} for the text file, produced from the
     * {@link #openBinFile(File)} method.
     * @return A {@code HashMap} with the contents of the specified dat file.
     */
    private HashMap<String, String> readBinFile(ObjectInputStream readStream) {
        HashMap<String, String> map = new HashMap<>();

        try {
            map = (HashMap<String, String>)readStream.readObject();
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }

        return map;
    }

    /**
     * Method for saving a {@code HashMap} to a dat file.
     * @param f The {@code File} to be saved to.
     * @param hm The {@code HashMap} to be saved.
     * @throws IOException When an error occurs in writing the file.
     */
    public void saveBinFile(File f, HashMap<String, String> hm) throws IOException {
        try {
            spWriter = new ObjectOutputStream(new FileOutputStream(f));
            spWriter.writeObject(hm);
        } catch(IOException e) {
            e.printStackTrace();
            System.exit(1);
        } catch(SecurityException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * Method for saving an {@code ArrayList<String>} to a text file.
     * @param f The file to save to.
     * @param arr The {@code ArrayList<String>} to save.
     * @throws IOException When an error occurs while writing.
     */
    public void saveTxtFile(File f, ArrayList<String> arr) throws IOException {
        try {
            txtWriter = new BufferedWriter(new FileWriter(f));
            for (int i = 0; i < arr.size(); i++) {
                String line = arr.get(i);
                txtWriter.write(line+"\n");
            }
        }catch(IOException e){
            e.printStackTrace();
            System.exit(1);
        }finally{
            txtWriter.close();
        }
    }

    /**
     * Method for creating the mysql {@code Connection}.
     * @return A {@link Connection} if the mysql server connects without errors, or {@code null} if the connection
     * cannot be established.
     */
    private Connection establishConnection(String dataBase, String dbUsername, String dbPassword) {
        try {
            Connection c = DriverManager.getConnection(dataBase ,dbUsername, dbPassword);
            System.out.print("Database successfully connected.");
            return c;
        } catch(SQLException e){
            System.out.println("Database could not be reached.");
            System.out.println("Continuing without mysql connection...");
            return null;
        }
    }

    /**
     * Method for checking user login credentials against stored data.
     * @param username The username entered by the user.
     * @param password The password entered by the user.
     * @return A role {@code int} depending on where a match is found for entered login credentials. 1 for Module
     * Coordinator, 2 for Project Supervisor, 3 for Student, and 0 for no match found.
     * @throws SQLException When a connection cannot be established with the mysql database.
     * @throws IOException When there is a problem opening and reading text files.
     */
    public int checkLoginCredentials(String username, String password) throws SQLException, IOException {
        String dataBase = "jdbc:mysql://localhost/sdd";
        String dbUsername = "root";
        String dbPassword = "";
        conn = establishConnection(dataBase, dbUsername, dbPassword);

        String user = null;
        String pass = null;
        int role = 0;

        if(conn!=null){
            Statement statement = conn.createStatement();

            String sql = "SELECT username, password, role FROM users ";
            ResultSet result = statement.executeQuery(sql);
            System.out.println("\nData Collected");

            while (result.next()) {
                user = result.getString("username");
                pass = result.getString("password");
                role = result.getInt("role");

                if (username.equals(user) && password.equals(pass)) {
                    return role;
                }
            }
            role = 0;
        } else {
            System.out.println("\nAlternative Login Database now in use...");

            BufferedReader mcReader = new BufferedReader(new FileReader("src/main/java/database/ModuleCo.bin"));        //Username Readers
            Scanner files = new Scanner(new File("src/main/java/database/ModuleCo.bin"));

            BufferedReader superReader = new BufferedReader(new FileReader("src/main/java/database/supervisorLogin.bin"));
            Scanner files2 = new Scanner(new File("src/main/java/database/supervisorLogin.bin"));

            BufferedReader stuReader = new BufferedReader(new FileReader("src/main/java/database/studentLogin.bin"));
            Scanner files3 = new Scanner(new File("src/main/java/database/studentLogin.bin"));

            BufferedReader passwordReader = new BufferedReader(new FileReader("src/main/java/database/ModuleCo.bin"));              //Separate Password Readers
            BufferedReader passwordReader2 = new BufferedReader(new FileReader("src/main/java/database/supervisorLogin.bin"));
            BufferedReader passwordReader3 = new BufferedReader(new FileReader("src/main/java/database/studentLogin.bin"));

            int mc = 0;
            while (files.hasNextLine()){
                mc++;                               //Integers count how many lines are in the Login.bin files
                files.nextLine();
            }

            int supervisor = 0;
            while (files2.hasNextLine()){
                supervisor++;
                files2.nextLine();
            }

            int stu = 0;
            while (files3.hasNextLine()){
                stu++;
                files3.nextLine();
            }

            for (int i = 0; i < mc; i++) {
                if (mcReader.readLine().equals("Username: " +username)){            //Nested for and if Statements to grab Username and Passwords set role number
                    for (int j = 0; j < mc; j++) {
                        if (passwordReader.readLine().equals("Password: " +password)){
                            role = 1;
                        }
                    }
                    if (role ==1) {
                        System.out.println("Welcome Module Coordinator");           //Verification for Module Coordinator Login
                    }
                }
            }

            for (int j = 0; j < supervisor; j++) {
                if (superReader.readLine().equals("Username: " +username)){
                    for (int i = 0; i < supervisor; i++) {
                        if (passwordReader2.readLine().equals("Password: " +password)){
                            role = 2;

                        }
                    }
                    if (role == 2) {
                        System.out.println("Welcome Project Supervisor");         //Verification for Project Supervisor Login
                    }
                }
            }

            for (int i = 0; i < stu; i++) {
                if (stuReader.readLine().contains("Username: " +username)){
                    for (int j = 0; j < stu; j++) {
                        if (passwordReader3.readLine().equals("Password: " +password)){
                            role = 3;
                        }
                    }
                    passwordReader3 = new BufferedReader(new FileReader("src/main/java/database/studentLogin.bin"));
                    if (role == 3) {
                        System.out.println("Welcome: " + username);              //Verification for Student Login
                    }
                }
            }

            return role;
        }

        return role;
    }

    /**
     * Method for reading certain datasets from the mysql database.
     * @param infoRequested A {@code String} which specifies the data requested by the system.
     * @return An {@code ArrayList<String>} with specific data depending on the value of the infoRequested parameter.
     * If "students" is given, an ArrayList of student names and UB numbers is returned, "projects" gives a list of
     * project names, anything else will give a list of assigned students and projects.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    public ArrayList<String> readFromConnection(String infoRequested) throws SQLException {
        if(infoRequested.equals("students")){
            return getSQLStudents();
        } else if (infoRequested.equals("projects")) {
            return getSQLProjects();
        } else {
            return getSQLAssigned();
        }
    }

    /**
     * Method for uploading assigned students and projects to the mysql table.
     * @param arr The {@code ArrayList<String>} of assigned students and projects.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    public void uploadAssigned(ArrayList<String> arr) throws SQLException {
        String clear = "DELETE FROM sp";                        //Deletes Previous table values

        PreparedStatement clearStatement = conn.prepareStatement(clear);
        clearStatement.executeUpdate();

        String sql = "INSERT INTO sp(studentp)" + "VALUES(?)";          //Replaces Previous assignments with the new student-project assignment
        PreparedStatement prepStatement = conn.prepareStatement(sql);

        for(int i = 0; i < arr.size(); i++){
            //gets line from assigned students-projects array
            String line = arr.get(i);

            prepStatement.setString(1, line);

            prepStatement.executeUpdate();              //Executes the update
        }
    }

    /**
     * Method for getting a list of students from the students table of the mysql database.
     * @return An {@code ArrayList<String>} of student names with UB numbers.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    private ArrayList<String> getSQLStudents() throws SQLException {
        String sql = "SELECT student FROM student";         //Get students from 'student' table in DB
        Statement statement = conn.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);
        ArrayList<String> students = new ArrayList<>();
        while(resultSet.next()){
            students.add(resultSet.getString("student"));              //Get student line by line in the ArrayList
        }
        return students;
    }

    /**
     * Method for getting a list of projects from the projects table of the mysql database.
     * @return An {@code ArrayList<String>} of project names.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    private ArrayList<String> getSQLProjects() throws SQLException {
        String sql = "SELECT project FROM projects";                //Get projects from 'projects' table in DB
        Statement statement = conn.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);
        ArrayList<String> projects = new ArrayList<>();
        while(resultSet.next()){
            projects.add(resultSet.getString("project"));           //Get projects line by line in the ArrayList
        }
        return projects;
    }

    /**
     * Method for getting a list of assigned students and projects from the studentp table of the mysql database.
     * @return An {@code ArrayList<String>} of assigned students and projects.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    private ArrayList<String> getSQLAssigned() throws SQLException {
        String sql = "SELECT studentp from sp";                     //Get student-projects from 'projects' table in DB
        Statement statement = conn.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);
        ArrayList<String> studentProjects = new ArrayList<>();
        while(resultSet.next()){
            studentProjects.add(resultSet.getString("studentp"));       //Get student-projects line by line in the ArrayList
        }
        return studentProjects;
    }

    /**
     * Method for writing a new user into the login database.
     * @param name The {@code String} new username of the user to be added.
     * @param pass The {@code String} new password of the user to be added.
     * @param role The {@code int} new role of the user to be added.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    public void writeToConnection(String name, String pass, int role) throws SQLException {
        if(role==3){
            addSQLStudents(name, pass);
        } else if (role==2) {
            addSQLSupervisors(name, pass);
        }
    }

    /**
     * Method for writing a new project to the projects table of the mysql database.
     * @param infoType The {@code String} info type to be written.
     * @param projectToAdd The {@code String} project name to add.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    public void writeToConnection(String infoType, String projectToAdd) throws SQLException {
        if(infoType.equals("project")){
            addSQLProject(projectToAdd);
        }
    }

    /**
     * Method for writing score edits to the studentp table of the mysql database.
     * @param infoType The {@code String} info type to be written.
     * @param newData The {@code ArrayList<String>} new score data to be written.
     * @throws SQLException When an error occurs querying the mysql database.
     */
    public void writeToConnection(String infoType, ArrayList<String> newData) throws SQLException {
        if (infoType.equals("assigned")) {
            addSQLAssignedEdits(newData);
        }
    }

    /**
     * Method for adding a project to the mysql database.
     * @param project The new project to add.
     */
    private void addSQLProject(String project) throws SQLException {
        String sql = "INSERT into projects(project)" +"VALUES(?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, project);
        preparedStatement.executeUpdate();
        System.out.println("Project Successfully added");
    }

    /**
     * Method for adding a student user to the database.
     * @param name The student username.
     * @param pass The student password.
     */
    private void addSQLStudents(String name, String pass) throws SQLException {
        String sql = "INSERT into student(student)" + "VALUES(?)";

        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.executeUpdate();

        String sql2 = "INSERT into users(username, password, role)" + "VALUES(?,?,3)";
        PreparedStatement preparedStatement1 = conn.prepareStatement(sql2);
        preparedStatement1.setString(1, name);
        preparedStatement1.setString(2, pass);
        preparedStatement1.executeUpdate();
        System.out.println("Student Successfully added");           //Verification for adding Student
    }

    /**
     * Method for adding a supervisor user to the database.
     * @param name The supervisor username.
     * @param pass The supervisor password.
     */
    private void addSQLSupervisors(String name, String pass) throws SQLException {
        String sql = "INSERT into supervisor(project_supervisor)" +"VALUES(?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.executeUpdate();

        String sql2 = "INSERT into users(username, password, role)" +"VALUES(?,?,2)";
        PreparedStatement preparedStatement1 = conn.prepareStatement(sql2);
        preparedStatement1.setString(1, name);
        preparedStatement1.setString(2, pass);
        preparedStatement1.executeUpdate();
        System.out.println("Supervisor Successfully added");
    }

    /**
     * Method for adding the score edits to the database.
     * @param newData The list of score edits.
     */
    private void addSQLAssignedEdits(ArrayList<String> newData) throws SQLException {
        String clearSQL = "DELETE FROM sp";
        PreparedStatement clearTable = conn.prepareStatement(clearSQL);
        clearTable.executeUpdate();

        String sql = "INSERT into sp(studentp)" +"VALUES(?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);

        String[] array = new String[(newData.size())];
        for (int i = 0; i < newData.size(); i++) {
            array[i] = newData.get(i);
        }

        for (String j: array){
            preparedStatement.setString(1, j);
            preparedStatement.executeUpdate();
        }
        System.out.println("Successfully Edited and Uploaded to DB");           //Verification for Editing scores
    }

}
