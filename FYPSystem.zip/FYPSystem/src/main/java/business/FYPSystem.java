package business;

import database.FYPDatabase;
import presentation.FYPGUI;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class for handling business layer operations. Can communicate with gui and database.
 */
public class FYPSystem {

    /**
     * {@code FYPDatabase} instance. Enables communication from system to database.
     */
    FYPDatabase db;

    /**
     * {@code FYPGUI} instance. Enables communication from system to gui.
     */
    FYPGUI gui;

    /**
     * {@code ArrayList} for storing text file contents.
     */
    private ArrayList<String> studentsArray, projectsArray;

    /**
     * {@code ArrayList} for storing conversion from {@code HashMap}.
     */
    private ArrayList<String> spArray;

    /**
     * {@code HashMap} for storing {@code HashMap} object read from students-projects file.
     */
    private HashMap<String, String> spMap;

    /**
     * {@code File} object for passing to the database layer and verifying various checks.
     */
    private File students, projects, studentsProjects;

    /**
     * Tracks whether the user is logged in or not. Important for the dbClose method.
     */
    private boolean loggedIn = false;

    /**
     * Set inside the checkLogin method. Tracks what kind of user is logged in. Important for the dbClose method.
     */
    private int userRole;

    /**
     * Constructor for {@code FYPSystem}. Initialises {@link #gui} attribute and {@link #db} attribute.
     * @param initGUI An instance of {@code FYPGUI}.
     * @param initDB An instance of {@code FYPDatabase}.
     */
    public FYPSystem(FYPGUI initGUI, FYPDatabase initDB) {
        db = initDB;
        gui = initGUI;
    }

    /**
     * Method to retrieve student data from the database layer. Data is stored in {@link #studentsArray}.
     * The data is then passed to the gui for the user to view. If the operation is cancelled or an error is
     * encountered, a notification is passed to the gui.
     */
    public void getStudents() {
        if(db.conn==null) {
            if (students == null) {
                students = gui.txtFileChoose();
                if (students != null && students.exists()) {
                    try {
                        studentsArray = db.openTextFile(students, "students");
                        gui.clearReader();
                        gui.printToReader("Students file contents:\n\n");
                        gui.printToReader(studentsArray);
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                } else {
                    gui.clearReader();
                    gui.printToReader("Open operation cancelled.");
                }
            } else {
                gui.clearReader();
                gui.printToReader("Error: Students file is already open. Click \"Close Files\" to close the file first.");
            }
        } else {
            try {
                studentsArray = db.readFromConnection("students");
                gui.printToReader(studentsArray);
            } catch (SQLException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

    /**
     * Method to retrieve project data from the database layer. Data is stored in {@link #projectsArray}.
     * The data is then passed to the gui for the user to view. If the operation is cancelled or an error is
     * encountered, a notification is passed to the gui.
     */
    public void getProjects() {
        if(db.conn==null) {
            if (projects == null) {
                projects = gui.txtFileChoose();
                if (projects.getAbsolutePath().contains("students.txt") && (userRole == 2 || userRole == 3)){
                    gui.clearReader();
                    gui.printToReader("You cannot view other students");
                }
                else {
                    if (projects != null && projects.exists()) {
                        try {
                            projectsArray = db.openTextFile(projects, "projects");
                            gui.clearReader();
                            gui.printToReader("Projects file contents:\n\n");
                            gui.printToReader(projectsArray);
                        } catch (IOException e) {
                            e.printStackTrace();
                            System.exit(1);
                        }
                    } else {
                        gui.clearReader();
                        gui.printToReader("Open operation cancelled.");
                    }
                }
            } else {
                gui.clearReader();
                gui.printToReader("Error: Projects file is already open. Click \"Close Files\" to close the file first.");
            }
        }else {
            try {
                projectsArray = db.readFromConnection("projects");
                gui.printToReader(projectsArray);
            } catch (SQLException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

    /**
     * Method to retrieve student-project data from the database layer. Data is stored in {@link #spArray} and
     * {@link #spMap}. The ArrayList can be used to print each entry with its associated assessment score.
     * The ArrayList is then passed to the gui for the user to view. If the operation is cancelled or an error is
     * encountered, a notification is passed to the gui.
     */
    public void getAssigned() {
        if(db.conn==null) {
            if (studentsProjects == null) {
                studentsProjects = gui.datFileChoose();
                if (studentsProjects != null && studentsProjects.exists()) {
                    try {
                        spMap = db.openBinFile(studentsProjects);
                        if (spMap != null) {
                            spArray = hashmapToArrayList(spMap);
                            gui.clearReader();
                            gui.printToReader("Students-projects file contents:\n\n");
                            gui.printToReader(spArray);
                        } else {
                            gui.clearReader();
                            studentsProjects = null;
                            db.closeFiles("sp reader");
                            gui.printToReader("The selected file contains no student-project data, and has been closed.");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                } else {
                    gui.clearReader();
                    gui.printToReader("Open operation cancelled.");
                }
            } else {
                gui.clearReader();
                gui.printToReader("Error: File is already open. Click \"Close Files\" to close the file first.");
            }
        } else {
            try {
                spArray = db.readFromConnection("assigned");
                gui.printToReader(spArray);
            } catch (SQLException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

    /**
     * Private method for converting {@link #spMap} to an {@code ArrayList}. Every entry in the {@link #spMap} is added to the
     * {@code ArrayList} to facilitate easy printing to the gui.
     * @param hm The {@link #spMap} retrieved by the {@link #getAssigned()} method.
     * @return An {@code ArrayList<String>} of assigned student-project data.
     */
    private ArrayList<String> hashmapToArrayList(HashMap<String, String> hm) {
        Set<Map.Entry<String, String>> entrySet = hm.entrySet();
        ArrayList<Map.Entry<String, String>> spEntryArray = new ArrayList<>(entrySet);
        ArrayList<String> tmp = new ArrayList<>();                       // Code for turning hashmap into arraylist to be displayed on txtReader
        for (Map.Entry<String, String> stringStringEntry : spEntryArray) {
            tmp.add(stringStringEntry.getKey() + stringStringEntry.getValue());
        }
        return tmp;
    }

    /**
     * Method for randomly assigning projects to students. A temporary copy of {@link #projectsArray} is initialised,
     * and a random project is chosen from it for every student in the {@link #studentsArray}. When a project is chosen,
     * it is removed from the temporary copy so that duplicate projects are not assigned. Every student and their
     * assigned project is added as a key to a {@code HashMap} with a value of "0/100" to indicate the assignment score.
     * The {@code HashMap} is then saved to a file of the user's choice, and uploaded to the mysql database if it is
     * connected.
     */
    public void assignProjects() {
        if(projectsArray != null && studentsArray != null) {
            if (studentsArray.size() > projectsArray.size()) {
                gui.clearReader();
                gui.printToReader("There needs to be more projects than students.");
            } else {
                Random random = new Random();
                HashMap<String, String> map = new HashMap<>();
                ArrayList<String> tempProjects = new ArrayList<>(projectsArray);

                for (int i = 0; i < studentsArray.size(); i++) {

                    int r = random.nextInt(tempProjects.size());
                    String proj = tempProjects.get(r);
                    String assigned = studentsArray.get(i) + " " + proj;
                    map.put(assigned, ": 0/100");
                    tempProjects.remove(r);

                }

                File fileToSave = gui.fileSave();
                boolean userConf = true;

                if (fileToSave.exists()) {
                    userConf = getUserConfirmation("overwrite");
                }

                if (fileToSave != null && userConf) {          //IntelliJ says fileToSave will always be '!= null', it's incorrect.
                    try {
                        db.saveBinFile(fileToSave, map);
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                    if (db.conn != null) {
                        try {
                            db.uploadAssigned(hashmapToArrayList(map));
                        } catch (SQLException e) {
                            e.printStackTrace();
                            System.exit(1);
                        }
                    }
                } else {
                    gui.clearReader();
                    gui.printToReader("Assignment operation cancelled.");
                }
            }
        } else{
            gui.clearReader();
            gui.printToReader("Must have open students.txt & projects.txt files to assign projects.");
        }

    }

    /**
     * Method for searching the students-projects file or database. Prints results to GUI.
     * @param query A user-specified {@code String}.
     */
    public void searchAssigned(String query) {
        ArrayList<String> results = new ArrayList<>();
        if(db.conn==null) {
            if (studentsProjects != null && studentsProjects.exists()) {
                if (query != null && !query.isBlank()) {
                    Pattern pt = Pattern.compile("(.*)(" + query + "+)(.*)");
                    for (int i = 0; i < spArray.size(); i++) {
                        Matcher m = pt.matcher(spArray.get(i));
                        if (m.matches()) {
                            String[] tmp = spArray.get(i).split(":");
                            results.add(tmp[0] + " | Score " + tmp[1]);
                        }
                    }
                    if (results.size() > 0) {
                        gui.printResults(results);
                    } else {
                        gui.clearReader();
                        gui.printToReader("No results found. The search query is case-sensitive!");
                    }
                } else {
                    gui.clearReader();
                    gui.printToReader("Enter a search query.");
                }
            } else {
                gui.clearReader();
                gui.printToReader("You must have an open students-projects file.");
            }
        }else {
            if (spArray != null) {
                if (query != null && !query.isBlank()) {
                    Pattern pt = Pattern.compile("(.*)(" + query + "+)(.*)");
                    for (String s : spArray) {
                        Matcher m = pt.matcher(s);
                        if (m.matches()) {
                            String[] tmp = s.split(":");
                            results.add(tmp[0] + " | Score " + tmp[1]);
                        }
                    }
                    if (results.size() > 0) {
                        gui.printResults(results);
                    }
                    else {
                        gui.clearReader();
                        gui.printToReader("No results found. The search query is case-sensitive!");
                    }
                }
                else {
                    gui.clearReader();
                    gui.printToReader("Enter a search query.");
                }
            }
            else {
                gui.clearReader();
                gui.printToReader("Make sure to assign the projects to the students first");
            }
        }
    }

    /**
     * Method for editing the score of a particular student-project entry.
     * @param entry The user-selected list item's contents.
     * @param edit The user edit to student project score.
     */
    public void editScore(String entry, String edit) {
        String userEdit = "";
        if(db.conn==null) {
            if (entry != null && edit != null) {
                userEdit = edit;
                String[] key = entry.split(" \\| Score ");

                spMap.replace(key[0], ": " + userEdit + "/100");

                gui.clearReader();
                gui.printToReader("Edit complete, make sure to save your changes.");
            } else if (entry == null) {
                gui.clearReader();
                gui.printToReader("Select an entry from the list after searching for your required student/project.");
            } else {
                gui.clearReader();
                gui.printToReader("The edit entered was not a number between 0 and 100. Try again.");
            }
        } else {
            if (entry != null && edit != null) {
                userEdit = edit.trim();
                String[] newEntryArr = entry.split(" \\| Score ");
                String newEntry = newEntryArr[0] + ": " + newEntryArr[1];
                spArray.remove(newEntry);
                newEntryArr = entry.split(" \\| Score  [0-9]+");
                newEntry = newEntryArr[0] + ": " + userEdit + newEntryArr[1];
                spArray.add(newEntry);
                gui.clearReader();
                gui.printToReader("Edit complete, make sure to save your changes.");
            }
            else if (entry == null) {
                gui.clearReader();
                gui.printToReader("Select an entry from the list after searching for your required student/project.");
            }
            else {
                gui.clearReader();
                gui.printToReader("The edit entered was not a number between 0 and 100. Try again.");
            }
        }
    }

    /**
     * Method for adding a project to the {@link #projectsArray} or to the database table if a connection is present.
     * @param projectToAdd The name of the project to add to the database.
     */
    public void addProject(String projectToAdd) {
        if(db.conn==null) {
            if(projects!=null && projectsArray!=null && projectToAdd!=null) {
                projectToAdd = projectToAdd.trim();
                projectsArray.add(projectToAdd);
                gui.clearReader();
                gui.printToReader("Project added. Remember to save your changes!");
            } else {
                gui.clearReader();
                gui.printToReader("Operation cancelled.\nEnsure you have an open projects file.");
            }
        } else {
            //code for mysql connection !=null
            try {
                db.writeToConnection("project", projectToAdd);
            } catch (SQLException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

    /**
     * Method for saving any edits made to currently uploaded students-projects data.
     * Called on the Module Coordinator GUI.
     */
    public void saveChanges() {
        if(db.conn==null) {
            File fileToSave = gui.fileSave();       //Calls gui's FileChooser with .dat file filter.
            boolean validFile = false;
            Pattern pt = Pattern.compile("(.*\\w+.*\\.dat)$");
            Matcher match = pt.matcher(fileToSave.getAbsolutePath());
            if (match.matches()) {        //Ensures selected file is a .dat file.
                validFile = true;
            }
            boolean userConf = true;
            if (fileToSave != null && spMap != null && validFile) {          //IntelliJ says fileToSave will always be '!= null', it's incorrect.

                if (fileToSave.exists()) {          //Asks user to overwrite file if an existing file is chosen.
                    userConf = getUserConfirmation("overwrite");
                }

                if (userConf) {
                    try {
                        db.saveBinFile(fileToSave, spMap);
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                } else {
                    gui.clearReader();
                    gui.printToReader("Save operation cancelled.");
                }

            } else {
                gui.clearReader();
                gui.printToReader("Save operation cancelled.\nEnsure you have uploaded some students-projects data." +
                        "\nEnsure you have chosen the correct file destination file format");
            }
        } else {
            if (spArray!=null){
                try{
                    db.writeToConnection("assigned", spArray);
                    gui.clearReader();
                    gui.printToReader("Data has been saved successfully. ");
                }
                catch(SQLException e){
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }
    }

    /**
     * Saves any edits made to the currently uploaded projects data. Called on the Project Supervisor GUI.
     */
    public void saveProjects() {
        File fileToSave = gui.fileSave();
        boolean validFile = false;

        Pattern pt = Pattern.compile("(.*\\w+.*\\.txt)$");
        Matcher match = pt.matcher(fileToSave.getAbsolutePath());
        if(match.matches()){        //Ensures selected file is a .dat file.
            validFile = true;
        }

        boolean userConf = true;
        if(fileToSave != null && projectsArray != null && validFile) { //IntelliJ says fileToSave will always be '!= null', it's incorrect.
            if (fileToSave.exists()) {                                 //Asks user to overwrite file if an existing file is chosen.
                userConf = getUserConfirmation("overwrite");
            }
            if (userConf) {
                try {
                    db.saveTxtFile(fileToSave, projectsArray);
                } catch (IOException e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            } else {
                gui.clearReader();
                gui.printToReader("Save operation cancelled.");
            }
        } else {
            gui.clearReader();
            gui.printToReader("Save operation cancelled.\nEnsure you have uploaded some students-projects data." +
                    "\nEnsure you have selected a file with a valid extension.");
        }
    }

    /**
     * Method for passing issues which need user action to the user interface.
     * @param issue A keyword specifying the issue which requires user verification.
     * @return A boolean value based on an option chosen by the user.
     */
    public boolean getUserConfirmation(String issue) {
        if ("overwrite".equals(issue)) {                //Can add more issues/keywords if needed.
            return gui.fileOverwrite();
        }
        return false;                                   //If no issue given, method always returns 'false'.
    }

    /**
     * Method for adding a user to the system login database.
     * @param usernameAndPassword A {@code String[]} array with the intended username at index 0 and intended password
     *                            at index 1.
     * @param role An {@code int} signifying the type of user privileges the new user should have.
     */
    public void addUser(String[] usernameAndPassword, int role) {
        if(db.conn!=null) {
            if (usernameAndPassword[0] != null && usernameAndPassword[1] != null) {
                Pattern pt = Pattern.compile("^\\s+$");
                Matcher match = pt.matcher(usernameAndPassword[0]);
                if (match.matches()) {
                    gui.clearReader();
                    gui.printToReader("Make sure that there are alphanumeric characters.");
                } else {
                    String name = usernameAndPassword[0].trim();
                    String pass = usernameAndPassword[1].trim();
                    try {
                        db.writeToConnection(name, pass, role);
                    } catch (SQLException e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                }
            } else {
                gui.clearReader();
                gui.printToReader("Make sure that none of the fields are null.");
            }
        } else {
            gui.clearReader();
            gui.printToReader("You can only add users while connected to the database.");
        }
    }

    /**
     * Method for closing the database files and clearing system data. This method must be called if the user wants to
     * open a second file of the same type e.g. a second students file. Also clears specific GUI components, depending
     * on {@link #userRole}.
     */
    public void dbClose() {
        db.closeAll();
        students = null;
        projects = null;
        studentsProjects = null;
        studentsArray = null;
        projectsArray = null;
        spArray = null;
        spMap = null;

        if(loggedIn && userRole==1) {       //Calls methods from gui to properly clear the Module Coordinator interface
            ArrayList<String> tmp = new ArrayList<>();
            gui.printResults(tmp);          //Clears results panel
            gui.clearReader();
            gui.printToReader("Closed all open files.");
        } else if (loggedIn) {
            gui.clearReader();
            gui.printToReader("Closed all open files.");
        }
    }

    /**
     * Method for checking user login credentials. Uses {@link FYPGUI#MC_GUI}, {@link FYPGUI#PS_GUI} and
     * {@link FYPGUI#S_GUI} to clearly show which roles are being checked. A specific GUI is then initialised depending
     * on the user role.
     * @param uName The {@code String} entered by the user to Username {@code JTextField}.
     * @param Pass The {@code String} entered by the user to Password {@code JPasswordField}.
     */
    public void checkLogin(String uName, String Pass) {
        try {
            if(uName!=null && Pass!=null) {
                int role = db.checkLoginCredentials(uName, Pass);
                if (role == FYPGUI.MC_GUI) {
                    gui.initGUI(FYPGUI.MC_GUI, gui);
                    loggedIn = true;
                    userRole = 1;
                } else if (role == FYPGUI.PS_GUI) {
                    gui.initGUI(FYPGUI.PS_GUI, gui);
                    loggedIn = true;
                    userRole = 2;                    // Will pass along role values to initialise specific panels in the initGUI method
                } else if (role == FYPGUI.S_GUI) {
                    gui.initGUI(FYPGUI.S_GUI, gui);
                    loggedIn = true;
                    userRole = 3;
                } else {
                    gui.initGUI(role, gui);
                }
            } else {
                gui.initGUI(0, gui);
            }
        } catch (SQLException | IOException e) {
            gui.initGUI(-1, gui);
        }
    }
}
