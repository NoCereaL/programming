package com.simon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Menu {
    public JFrame frame;
    public JButton start;

    public class panel extends JLayeredPane{
        public JLabel title;
        public JLabel background;

        public panel(){
            Font t = new Font("arial",Font.BOLD,20);
            title = new JLabel("Welcome to Simon's BrickBreaker");
            title.setFont(t);
            title.setForeground(Color.green);
            title.setBounds(135,100,2000,50);

            start = new JButton("Start Game");
            start.setBounds(200,600,200,30);
            start.setBackground(Color.green);
            start.addActionListener(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new GUI();
                    frame.setVisible(false);
                }
            });

            background = new JLabel();
            background.setOpaque(true);
            background.setBackground(Color.black);
            background.setBounds(0,0,600,800);

            add(title);
            add(start);
            add(background);
        }
    }

    public Menu(){
        frame = new JFrame();
        frame.add(new panel());
        frame.setTitle("BrickBreaker Menu");
        frame.setSize(600,800);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
