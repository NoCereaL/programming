package com.simon;

public class Launcher {

    public static void main(String[] args) {
	    new Menu();
    }
}
