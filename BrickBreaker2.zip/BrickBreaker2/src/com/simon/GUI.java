package com.simon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GUI extends JFrame implements KeyListener {
    public JFrame frame;
    Rectangle r = new Rectangle();
    Rectangle c = new Rectangle();
    Rectangle block = new Rectangle();
    Rectangle block2 = new Rectangle();
    Rectangle block3 = new Rectangle();
    public JLabel score;
    public int point = 0;

    public int BOX_HEIGHT = 800;
    public int BOX_WIDTH = 600;

    public int radius = 50;
    public double x = c.getX();
    public double y = c.getY();
    public int xSpeed = 2;
    public int ySpeed = 2;

    public double circleXPos = 300;
    public double circleYPos = 500;

    public double xPos = 200;
    public double yPos = 600;

    public double rectX = r.getX();
    public double rectY = r.getY();

    //Block Dimensions
    public int blockHeight = 30;
    public int blockWidth = 100;

    @Override
    public void keyTyped(KeyEvent e) { }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_LEFT: moveLeft(); repaint(); break;
            case KeyEvent.VK_RIGHT: moveRight(); repaint(); break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    public class move extends JPanel{
        public int blockX = 100;
        public int blockY = 200;
        public int blockX2 = 250;
        public int blockY2 = 200;
        public int blockX3 = 400;
        public int blockY3 = 200;
        public int blockX4 = 100;
        public int blockY4 = 100;
        public int blockX5 = 250;
        public int blockY5 = 100;
        public int blockX6 = 400;
        public int blockY6 = 100;

        public void paintComponent(Graphics graphics){
            graphics.setColor(Color.black);
            graphics.fillRect(0,0,BOX_WIDTH,BOX_HEIGHT);
            Circle(graphics);
            Rectangle(graphics);
            Block(graphics);
        }

        public void Circle(Graphics graphics){
            c.height = radius;
            c.width = radius;
            graphics.setColor(Color.green);
            graphics.fillOval((int) x,(int) y,c.width,c.height);
        }

        public void Rectangle(Graphics graphics){
            r.width = 200;
            r.height = 30;
            graphics.setColor(Color.red);
            graphics.fillRect((int) rectX,(int) rectY,r.width,r.height);
        }

        public int scoreX = 300;
        public int scoreY = 50;

        public void Score(){
            score = new JLabel("Score: --");
            score.setBounds(scoreX,scoreY,100,50);
        }

        public void Block(Graphics graphics){
            graphics.setColor(Color.blue);
            graphics.fillRect(blockX,blockY,blockWidth,blockHeight);

            graphics.setColor(Color.blue);
            graphics.fillRect(blockX2,blockY2,blockWidth,blockHeight);

            graphics.setColor(Color.blue);
            graphics.fillRect(blockX3,blockY3,blockWidth,blockHeight);

            graphics.setColor(Color.orange);
            graphics.fillRect(blockX4,blockY4,blockWidth,blockHeight);

            graphics.setColor(Color.orange);
            graphics.fillRect(blockX5,blockY5,blockWidth,blockHeight);

            graphics.setColor(Color.orange);
            graphics.fillRect(blockX6,blockY6,blockWidth,blockHeight);
        }

        public move(){
            rectX = xPos;
            rectY = yPos;
            x = circleXPos;
            y = circleYPos;
            Score();
            add(score);
            Thread thread = new Thread(){
                @Override
                public void run() {
                    while (true) {
                        x = x+xSpeed;
                        y = y+ySpeed;
                        if (x < 0) {
                            xSpeed = -xSpeed;
                        } else if (x > BOX_WIDTH - radius) {
                            xSpeed = -xSpeed;
                        }
                        if (y < 0){
                            ySpeed = -ySpeed;
                        } else if (y > BOX_HEIGHT - radius){
                            ySpeed = -ySpeed;
                            System.exit(0);
                        }

                        if (rectY == y+c.height){
                            if (x >= rectX-50 && x <= rectX+r.width){
                                ySpeed = -ySpeed;
                            }
                        }
                        if (rectX-50 == x+c.width){
                            if (y >= rectY && y <= rectY+r.height){
                                xSpeed = -xSpeed;
                            }
                        }
                        if (y == blockY){
                            if (x >= blockX-50 && x <= blockX+blockWidth){
                                ySpeed = -ySpeed;
                                blockX = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        if (y == blockY2){
                            if (x >= blockX2-50 && x <= blockX2+blockWidth){
                                ySpeed = -ySpeed;
                                blockX2 = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        if (y == blockY3){
                            if (x >= blockX3-50 && x <= blockX3+blockWidth){
                                ySpeed = -ySpeed;
                                blockX3 = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        if (y == blockY4){
                            if (x >= blockX4-50 && x <= blockX4+blockWidth){
                                ySpeed = -ySpeed;
                                blockX4 = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        if (y == blockY5){
                            if (x >= blockX5-50 && x <= blockX5+blockWidth){
                                ySpeed = -ySpeed;
                                blockX5 = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        if (y == blockY6){
                            if (x >= blockX6-50 && x <= blockX6+blockWidth){
                                ySpeed = -ySpeed;
                                blockX6 = 1000;
                                point = point + 10;
                                score.setText("Score: " +point);
                                //repaint();
                            }
                        }

                        repaint();
                        try{
                            Thread.sleep(30);
                        } catch (InterruptedException e){}
                    }
                }
            };
            thread.start();
        }
    }

    public void moveLeft(){
        if (rectX != 0) {
            rectX = rectX - 10;
        }
    }
    public void moveRight(){
        if (rectX+r.width != BOX_WIDTH) {
            rectX = rectX + 10;
        }
    }

    public GUI(){
        frame = new JFrame();
        GraphicsEnvironment graphics = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice graphicsDevice = graphics.getDefaultScreenDevice();
        graphicsDevice.setFullScreenWindow(frame);

        frame.add(new move());
        frame.setTitle("Brick Breaker");
        frame.setSize(600,800);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.addKeyListener(this);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new GUI();
    }
}
