package com.simon;

import javax.swing.*;
import java.awt.*;

public class Labels {
    public JLabel label;
    public JLabel label2;
    public JLabel label3;
    public JLabel multiplayer;
    public JLabel label4;
    public JLabel label5;
    public JLabel label6;
    public JLabel label7;

    public JLabel twoLabel;
    public JLabel twoLabel2;
    public JLabel twoLabel3;

    public JLabel titleScreen;
    public JLabel playerOne;
    public JLabel playerTwo;
    public JLabel scoreOne;
    public JLabel scoreTwo;

    public Labels(){
        Font title = new Font("arial", Font.BOLD, 32);
        Font text = new Font("arial", Font.BOLD, 20);
        Font Instructions = new Font("serif", Font.BOLD, 25);

        label = new JLabel("Welcome to the Dungeon RUN");
        label.setFont(title);
        label.setForeground(Color.red);
        label.setBounds(450,50,600,50);

        label2 = new JLabel("Please Select Difficulty level");
        label2.setFont(text);
        label2.setForeground(Color.red);
        label2.setBounds(550,100,600,30);

        label3 = new JLabel("");
        label3.setForeground(Color.red);
        label3.setBounds(615,500,200,20);

        multiplayer = new JLabel("");
        multiplayer.setBounds(610,520,200,20);

        label4 = new JLabel("Instructions");
        label4.setFont(Instructions);
        label4.setForeground(Color.gray);
        label4.setBounds(100,70,200,200);

        label7 = new JLabel("<html>Hard Mode <br/>You Only Have 100 Health <br/>Monster Have 110 Health, so be careful :) <br/>Press Button 'P' to use portals" +
                "<br/> Move in and out of hearts to replenish your health <br/>Monster and Ghost(Player 2) can eat you if they attack Vertically, So Careful <br/>Monsters and Ghost can merge to do double damage<br/>Get to the Stairs to complete the Level</html>", SwingConstants.CENTER);
        label7.setBounds(102,170,250,200);
        label7.setForeground(Color.yellow);
        label7.setVisible(false);

        label5 = new JLabel("<html>Easy Mode <br/>You Have 300 Health <br/>Monsters Have 40 Health, Noob <br/>Press Button 'P' to use portals" +
                "<br/> Move in and out of hearts to replenish your health <br/>Monster and Ghost(Player 2) can eat you if they attack Vertically, So Careful <br/>Monsters and Ghost can merge to do double damage<br/>Get to the Stairs to complete the Level</html>", SwingConstants.CENTER);
        label5.setBounds(102,170,250,200);
        label5.setForeground(Color.yellow);
        label5.setVisible(false);

        label6 = new JLabel("<html>Normal Mode <br/>You Only Have 200 Health <br/>Monster Have 70 Health <br/>Press Button 'P' to use portals" +
                "<br/> Move in and out of hearts to replenish your health <br/>Monster and Ghost(Player 2) can eat you if they attack Vertically, So Careful <br/>Monsters and Ghost can merge to do double damage<br/>Get to the Stairs to complete the Level</html>", SwingConstants.CENTER);
        label6.setBounds(102,170,250,200);
        label6.setForeground(Color.yellow);
        label6.setVisible(false);

        twoLabel = new JLabel("<html>Ahh, You Have Chosen Two Player Mode? <br/>Player Two Has 300 Health <br/>Press Button 'E' to use portals" +
                "<br/> W A S D, Are the directional keys for Player Two</html>");
        twoLabel.setBounds(102,310,250,200);
        twoLabel.setVisible(false);

        twoLabel2 = new JLabel("<html>Ahh, You Have Chosen Two Player Mode? <br/>Player Two Has 200 Health <br/>Press Button 'E' to use portals" +
                "<br/> W A S D, Are the directional keys for Player Two</html>");
        twoLabel2.setBounds(102,310,250,200);
        twoLabel2.setVisible(false);

        twoLabel3 = new JLabel("<html>Ahh, You Have Chosen Two Player Mode? <br/>Player Two Has 100 Health <br/>Press Button 'E' to use portals" +
                "<br/> W A S D, Are the directional keys for Player Two</html>");
        twoLabel3.setBounds(102,310,250,200);
        twoLabel3.setVisible(false);

        Font ti = new Font("arial", Font.BOLD, 30);
        titleScreen = new JLabel("You Defeated the Dungeon!!!");
        titleScreen.setBounds(470,50,2000,50);
        titleScreen.setFont(ti);
        titleScreen.setForeground(Color.red);

        Font player = new Font("arial",Font.BOLD,25);
        playerOne = new JLabel("Player One Achieved:");
        playerOne.setFont(player);
        playerOne.setForeground(Color.BLUE);
        playerOne.setBounds(200,200,2000,50);

        playerTwo = new JLabel("Player Two Achieved:");
        playerTwo.setFont(player);
        playerTwo.setForeground(Color.BLUE);
        playerTwo.setBounds(900,200,2000,50);

        Font score = new Font("arial", Font.BOLD, 20);
        scoreOne = new JLabel("Score: --");
        scoreOne.setForeground(Color.GREEN);
        scoreOne.setFont(score);
        scoreOne.setBounds(280,240,2000,50);

        scoreTwo = new JLabel("Score: --");
        scoreTwo.setForeground(Color.GREEN);
        scoreTwo.setFont(score);
        scoreTwo.setBounds(980,240,2000,50);
    }
}

