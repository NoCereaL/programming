package com.simon;

import com.sun.tools.javac.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Menu {
    private JFrame frame;
    private JLayeredPane pane;
    private JLabel picture;

    public Menu(){

        Buttons b = new Buttons();
        Labels l = new Labels();

        frame = new JFrame("Dungeon Menu");

        ImageIcon img = new ImageIcon("assets/mons.gif");
        picture = new JLabel("",img,JLabel.CENTER);
        picture.setSize(1366,768);

        pane = new JLayeredPane();
        pane.setBounds(0,0,1366,768);

        b.onePlayer.setVisible(false);
        b.twoPlayer.setVisible(false);

        pane.add(l.label);
        pane.add(l.label2);
        pane.add(l.label3);
        pane.add(l.multiplayer);
        pane.add(b.button);
        pane.add(b.button2);
        pane.add(b.button3);
        pane.add(b.start);
        pane.add(b.onePlayer);
        pane.add(b.twoPlayer);

        pane.add(l.label4);
        pane.add(l.label5);
        pane.add(l.label6);
        pane.add(l.label7);
        pane.add(l.twoLabel);
        pane.add(l.twoLabel2);
        pane.add(l.twoLabel3);

        pane.add(picture);

        frame.add(pane);
        frame.setSize(1366,768);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);


        b.button.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameGUI gui = new GameGUI();            //create GUI
                gui.setVisible(false);                   //display GUI
                GameEngine eng = new GameEngine(gui);   //create engine
                DungeonInputHandler i = new DungeonInputHandler(eng);   //create input handler
                gui.registerKeyHandler(i);
                eng.depth = 1;
                eng.health = 300;
                eng.monsterHealth = 40;
                eng.startGame();
                l.label3.setText("Easy Mode Selected");
                l.label3.setForeground(Color.green);
                l.label5.setVisible(true);
                b.button.setVisible(false);
                b.button2.setVisible(false);
                b.button3.setVisible(false);
                b.onePlayer.setVisible(true);
                b.twoPlayer.setVisible(true);

                b.twoPlayer.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        eng.startGame2();
                        l.multiplayer.setText("2 Player Mode Selected");
                        l.multiplayer.setForeground(Color.cyan);
                        l.twoLabel.setVisible(true);
                        l.twoLabel.setForeground(Color.yellow);
                        gui.canvas.scoreTwo.setVisible(true);
                        gui.canvas.ptwo.setVisible(true);
                        b.start.setVisible(true);

                        b.start.addActionListener(new AbstractAction() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                gui.setVisible(true);
                                frame.setVisible(false);
                            }
                        });
                    }
                });

                b.start.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        gui.setVisible(true);
                        frame.setVisible(false);
                    }
                });
            }
        });
        b.button2.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameGUI gui = new GameGUI();            //create GUI
                gui.setVisible(false);                   //display GUI
                GameEngine eng = new GameEngine(gui);   //create engine
                DungeonInputHandler i = new DungeonInputHandler(eng);   //create input handler
                gui.registerKeyHandler(i);
                eng.depth = 3;
                eng.health = 200;
                eng.monsterHealth = 150;
                eng.startGame();
                l.label3.setText("Normal Mode Selected");
                l.label3.setForeground(Color.orange);
                l.label6.setVisible(true);
                b.button.setVisible(false);
                b.button2.setVisible(false);
                b.button3.setVisible(false);
                b.onePlayer.setVisible(true);
                b.twoPlayer.setVisible(true);

                b.twoPlayer.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        eng.startGame2();
                        l.multiplayer.setText("2 Player Mode Selected");
                        l.multiplayer.setForeground(Color.cyan);
                        l.twoLabel2.setVisible(true);
                        l.twoLabel2.setForeground(Color.yellow);
                        gui.canvas.scoreTwo.setVisible(true);
                        gui.canvas.ptwo.setVisible(true);
                        b.start.setVisible(true);

                        b.start.addActionListener(new AbstractAction() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                gui.setVisible(true);
                                frame.setVisible(false);
                            }
                        });
                    }
                });

                b.start.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        gui.setVisible(true);
                        frame.setVisible(false);
                    }
                });
            }
        });
        b.button3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameGUI gui = new GameGUI();            //create GUI
                gui.setVisible(false);                   //display GUI
                GameEngine eng = new GameEngine(gui);   //create engine
                DungeonInputHandler i = new DungeonInputHandler(eng);   //create input handler
                gui.registerKeyHandler(i);
                eng.depth = 20;
                eng.health = 100;
                eng.monsterHealth = 200;
                eng.startGame();
                l.label3.setText("Hard Mode Selected!!!");
                l.label3.setForeground(Color.red);
                l.label7.setVisible(true);
                b.button.setVisible(false);
                b.button2.setVisible(false);
                b.button3.setVisible(false);
                b.onePlayer.setVisible(true);
                b.twoPlayer.setVisible(true);

                b.twoPlayer.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        eng.startGame2();
                        l.multiplayer.setText("2 Player Mode Selected");
                        l.multiplayer.setForeground(Color.cyan);
                        l.twoLabel3.setVisible(true);
                        l.twoLabel3.setForeground(Color.yellow);
                        gui.canvas.scoreTwo.setVisible(true);
                        gui.canvas.ptwo.setVisible(true);
                        b.start.setVisible(true);

                        b.start.addActionListener(new AbstractAction() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                gui.setVisible(true);
                                frame.setVisible(false);
                            }
                        });
                    }
                });

                b.start.addActionListener(new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        gui.setVisible(true);
                        frame.setVisible(false);
                    }
                });
            }
        });

        b.onePlayer.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                l.multiplayer.setText("1 Player Mode Selected");
                l.multiplayer.setForeground(Color.cyan);
                l.twoLabel.setVisible(false);
                b.start.setVisible(true);

            }
        });


    }
}
