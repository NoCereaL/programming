package com.simon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Buttons {
    public JButton button;
    public JButton button2;
    public JButton button3;
    public JButton onePlayer;
    public JButton twoPlayer;
    public JButton start;
    public JButton exit;
    public JButton playAgain;

    public Buttons(){
        Font startfont = new Font("arial", Font.BOLD, 17);

        button = new JButton("Easy");
        button.setBounds(575,200,200,30);

        button2 = new JButton("Normal");
        button2.setBounds(575,300,200,30);

        button3 = new JButton("Hard!");
        button3.setBounds(575,400,200,30);

        start = new JButton("Start Game");
        start.setFont(startfont);
        start.setBackground(Color.green);
        start.setBounds(555,600,250,50);
        start.setVisible(false);

        onePlayer = new JButton("1 Player Mode");
        onePlayer.setBounds(575,200,200,30);

        twoPlayer = new JButton("2 Player Mode");
        twoPlayer.setBounds(575,300,200,30);

        exit = new JButton("Exit Game");
        exit.setBounds(580,650,200,30);
        exit.setBackground(Color.red);

        playAgain = new JButton("Play Again");
        playAgain.setBounds(580,600,200,30);
        playAgain.setBackground(Color.green);
    }
}

