package com.simon;

public class Scores {
    public int score = 0;
    public int score2 = 0;
}
