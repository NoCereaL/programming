package com.simon;

import jdk.jfr.Enabled;

import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.geom.Point2D;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * The GameEngine class is responsible for managing information about the game,
 * creating levels, the player and monsters, as well as updating information
 * when a key is pressed while the game is running.
 * @author prtrundl
 */
public class GameEngine {

    /**
     * An enumeration type to represent different types of tiles that make up
     * a dungeon level. Each type has a corresponding image file that is used
     * to draw the right tile to the screen for each tile in a level. Floors are
     * open for monsters and the player to move into, walls should be impassable,
     * stairs allow the player to progress to the next level of the dungeon, and
     * chests can yield a reward when moved over.
     */
    public enum TileType {
        WALL, FLOOR, HEART, STAIRS, LAVA, PORTAL
    }

    /**
     * The width of the dungeon level, measured in tiles. Changing this may
     * cause the display to draw incorrectly, and as a minimum the size of the
     * GUI would need to be adjusted.
     */
    public static final int DUNGEON_WIDTH = 25;

    /**
     * The height of the dungeon level, measured in tiles. Changing this may
     * cause the display to draw incorrectly, and as a minimum the size of the
     * GUI would need to be adjusted.
     */
    public static final int DUNGEON_HEIGHT = 24;

    /**
     * The maximum number of monsters that can be generated on a single level
     * of the dungeon. This attribute can be used to fix the size of an array
     * (or similar) that will store monsters.
     */
    public static final int MAX_MONSTERS = 40;

    /**
     * The chance of a wall being generated instead of a floor when generating
     * the level. 1.0 is 100% chance, 0.0 is 0% chance.
     */
    public static final double WALL_CHANCE = 0.05;

    /**
     * A random number generator that can be used to include randomised choices
     * in the creation of levels, in choosing places to spawn the player and
     * monsters, and to randomise movement and damage. This currently uses a seed
     * value of 123 to generate random numbers - this helps you find bugs by
     * giving you the same numbers each time you run the program. Remove
     * the seed value if you want different results each game.
     */
    private Random rng = new Random(123);

    /**
     * The current level number for the dungeon. As the player moves down stairs
     * the level number should be increased and can be used to increase the
     * difficulty e.g. by creating additional monsters with more health.
     */
    Buttons b = new Buttons();
    public int depth = 1;  //current dungeon level

    /**
     * The GUI associated with a GameEngine object. THis link allows the engine
     * to pass level (tiles) and entity information to the GUI to be drawn.
     */
    private GameGUI gui;

    /**
     * The 2 dimensional array of tiles the represent the current dungeon level.
     * The size of this array should use the DUNGEON_HEIGHT and DUNGEON_WIDTH
     * attributes when it is created.
     */
    private TileType[][] tiles;

    /**
     * An ArrayList of Point objects used to create and track possible locations
     * to spawn the player and monsters.
     */
    private ArrayList<Point> spawns;

    /**
     * An Entity object that is the current player. This object stores the state
     * information for the player, including health and the current position (which
     * is a pair of co-ordinates that corresponds to a tile in the current level)
     */
    private Entity player;
    private Entity player2;

    /**
     * An array of Entity objects that represents the monsters in the current
     * level of the dungeon. Elements in this array should be of the type Entity,
     * meaning that a monster is alive and needs to be drawn or moved, or should
     * be null which means nothing is drawn or processed for movement.
     * Null values in this array are skipped during drawing and movement processing.
     * Monsters (Entity objects) that die due to player attacks can be replaced
     * with the value null in this array which removes them from the game.
     */
    private Entity[] monsters;
    private Entity[] ghosts;

    /**
     * Constructor that creates a GameEngine object and connects it with a GameGUI
     * object.
     * @param gui The GameGUI object that this engine will pass information to in
     * order to draw levels and entities to the screen.
     */
    public GameEngine(GameGUI gui) {
        this.gui = gui;
        //startGame();
    }


    /**
     * Generates a new dungeon level. The method builds a 2D array of TileType values
     * that will be used to draw tiles to the screen and to add a variety of
     * elements into each level. Tiles can be floors, walls, stairs (to progress
     * to the next level of the dungeon) or chests. The method should contain
     * the implementation of an algorithm to create an interesting and varied
     * level each time it is called.
     * @return A 2D array of TileTypes representing the tiles in the current
     * level of the dungeon. The size of this array should use the width and
     * height of the dungeon.
     */
    private TileType[][] generateLevel() {
        TileType[][] level = new TileType[DUNGEON_HEIGHT][DUNGEON_WIDTH];
        Random r = new Random(depth);
        /*for (int i = 0; i < level.length; i++) {
            for (int j = 0; j < level.length; j++) {
                level[i][j] = TileType.WALL;
            }
        }*/
        for (int i = 0; i < level.length-1; i++) {
            for (int j = 0; j < level.length-1; j++) {
                level[i][j] = TileType.FLOOR;
            }
        }
        int lavaChance = 0;
        for (int i = 0; i < 4; i++) {
            if (depth == 3+i){
                lavaChance = 1+i;
            }
            if (depth >= 7){
                lavaChance = 10;
            }
            if (depth >= 10){
                lavaChance = 20;
            }
        }
        if (depth >= 3){
            for (int j = 0; j < 1+lavaChance; j++) {
                int x = r.nextInt(level.length);
                int y = r.nextInt(level.length);
                level[x][y] = TileType.LAVA;
            }}
        int heartChance = 0;
        for (int i = 0; i < 4; i++) {
            if (depth == 3+i){
                heartChance = 1+i;
            }
            if (depth >= 7){
                heartChance = 7;
            }
        }

        for (int i = 0; i < level.length; i++) {
            for (int j = 0; j < 1; j++) {
                level[i][j] = TileType.WALL;
            }
        }
        for (int i = 0; i < 1; i++) {
            for (int j = 0; j < level.length; j++) {
                level[i][j] = TileType.WALL;
            }
        }
        for (int i = level.length-1; i < level.length; i++) {
            for (int j = 0; j < level.length; j++) {
                level[i][j] = TileType.WALL;
            }
        }
        for (int i = 0; i < level.length; i++) {
            for (int j = level.length-1; j < level.length; j++) {
                level[i][j] = TileType.WALL;
            }
        }
        int WallChance = 0;
        for (int i = 0; i < 4; i++) {
            if (depth == 3+i){
                WallChance = 1+i;
            }
            if (depth >= 8){
                WallChance = 5;
            }
        }
        for (int i = 0; i < 6+WallChance; i++) {
            for (int j = 0; j < 6+WallChance; j++) {
                int x = r.nextInt(level.length);
                int y = r.nextInt(level.length);
                //int x = (int)(Math.random() * level.length);
                //int y = (int)(Math.random() * level.length);
                level[x][y] = TileType.WALL;
            }
        }

        for (int i = 1; i < 3; i++) {
            for (int j = 1; j < 3; j++) {
                level[i][j] = TileType.FLOOR;
            }
        }
        int portalChance = 0;
        if (depth >= 8){
            portalChance = 1;
        }
        if (depth >= 10){
            portalChance = 2;
        }
        if (depth >= 3){
            for (int i = 0; i < 1+portalChance; i++) {
                int x = r.nextInt(level.length);
                int y = r.nextInt(level.length);
                level[x][y] = TileType.PORTAL;
            }
        }
        //for (int i = 0; i < 1; i++) {
        for (int j = 0; j < 1; j++) {
            int x = r.nextInt(23);
            int y = r.nextInt(23);
            if (x < 1){ x = 2; }
            if (y < 1){ y = 2; }
            else if (x > 16){ x = 16; }
            else if (y > 16){ y = 16; }
            level[x][y] = TileType.STAIRS;
        }
        //}
        if (depth >= 3){
            for (int j = 0; j < 1+heartChance; j++) {
                int x = r.nextInt(level.length);
                int y = r.nextInt(level.length);
                level[x][y] = TileType.HEART;
            }}

        //Add your code here to build a 2D array containing TileType values to create a level
        return level;   //return the 2D array
    }


    /**
     * Generates spawn points for the player and monsters. The method processes
     * the tiles array and finds tiles that are suitable for spawning, i.e.
     * tiles that are not walls or stairs. Suitable tiles should be added
     * to the ArrayList that will contain Point objects - Points are a
     * simple kind of object that contain an X and a Y co-ordinate stored using
     * the int primitive type and are part of the Java language (search for the
     * Point API documentation and examples of their use)
     * @return An ArrayList containing Point objects representing suitable X and
     * Y co-ordinates in the current level that the player or monsters can be
     * spawned in
     */
    private ArrayList<Point> getSpawns() {
        ArrayList tile = new ArrayList();
        ArrayList<Point> s = new ArrayList<Point>();

        for (int i = 0; i < generateLevel().length; i++) {
            for (int j = 0; j < generateLevel().length; j++) {
                Point floors = new Point(i,j);
                if (generateLevel()[i][j] == TileType.FLOOR){
                    s.add(floors);
                }
            }
        }

        Point playerSpawn = new Point(1,1);
        Point playerTwoSpawn = new Point(22,22);
        Point floors = new Point(rng.nextInt(), rng.nextInt());
        s.add(floors);
        Point restrict = new Point(1,2);
        Point res2 = new Point(2,2);
        Point res3 = new Point(2,1);
        s.remove(restrict);
        s.remove(res2);
        s.remove(res3);
        s.remove(playerSpawn);
        s.remove(playerTwoSpawn);
        //Add code here to find tiles in the level array that are suitable spawn points
        //Add these points to the ArrayList s
        return s;
    }

    /**
     * Spawns monsters in suitable locations in the current level. The method
     * uses the spawns ArrayList to pick suitable positions to add monsters,
     * removing these positions from the spawns ArrayList as they are used
     * (using the remove() method) to avoid multiple monsters spawning in the
     * same location. The method creates monsters by instantiating the Entity
     * class, setting health, and setting the X and Y position for the monster
     * using the X and Y values in the Point object removed from the spawns ArrayList.
     * @return A array of Entity objects representing the monsters for the current
     * level of the dungeon
     */
    public int monsterHealth = 50;
    private Entity[] spawnMonsters() {
        Point p = new Point(9,9);
        Point random = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random1 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random2 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random3 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));


        Entity monster = new Entity(monsterHealth, p.x, p.y, Entity.EntityType.MONSTER);
        Entity monster2 = new Entity(monsterHealth,random2.x,random2.y, Entity.EntityType.MONSTER);
        Entity monster3 = new Entity(monsterHealth, random.x, random.y, Entity.EntityType.MONSTER);
        Entity monster4 = new Entity(monsterHealth, random1.x, random1.y, Entity.EntityType.MONSTER);
        Entity monster5 = new Entity(monsterHealth, random3.x, random3.y, Entity.EntityType.MONSTER);

        monsters = new Entity[]{monster};

        if (depth == 2){
            monsters = new Entity[]{monster, monster2};
        }

        if (depth == 3){
            monsters = new Entity[]{monster, monster2, monster3};
        }

        if (depth == 4){
            monsters = new Entity[]{monster, monster2, monster3, monster4};
        }

        if (depth == 5) {
            monsters = new Entity[]{monster, monster2,monster3,monster4,monster5};
        }

        if (depth >= 5){
            monsters = new Entity[]{monster, monster2,monster3,monster4,monster5};
        }
        if (depth > 15){
            monster.changeHealth(monsterHealth+50);
            monster2.changeHealth(monsterHealth+50);
            monster3.changeHealth(monsterHealth+50);
            monster4.changeHealth(monsterHealth+50);
            monster5.changeHealth(monsterHealth+50);
            monsters = new Entity[]{monster, monster2,monster3,monster4,monster5};
        }

        return monsters;    //Should be changed to return an array of monsters instead of null
    }

    private Entity[] spawnGhosts() {
        Point p = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random1 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random2 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));
        Point random3 = new Point(getSpawns().get((int)(Math.random()* getSpawns().size())));


        Entity ghost = new Entity(monsterHealth, p.x, p.y, Entity.EntityType.GHOST);
        Entity ghost2 = new Entity(monsterHealth,random2.x,random2.y, Entity.EntityType.GHOST);
        Entity ghost3 = new Entity(monsterHealth, random.x, random.y, Entity.EntityType.GHOST);
        Entity ghost4 = new Entity(monsterHealth, random1.x, random1.y, Entity.EntityType.GHOST);
        Entity ghost5 = new Entity(monsterHealth, random3.x, random3.y, Entity.EntityType.GHOST);

        ghosts = new Entity[]{ghost};

        if (depth == 2){
            ghosts = new Entity[]{ghost, ghost2};
        }

        if (depth == 3){
            ghosts = new Entity[]{ghost, ghost2, ghost3};
        }

        if (depth == 4){
            ghosts = new Entity[]{ghost, ghost2, ghost3, ghost4};
        }

        if (depth == 5) {
            ghosts = new Entity[]{ghost, ghost2,ghost3,ghost4,ghost5};
        }
        if (depth >= 5){
            ghosts = new Entity[]{ghost, ghost2,ghost3,ghost4,ghost5};
        }
        if (depth > 15){
            ghost.changeHealth(monsterHealth+50);
            ghost2.changeHealth(monsterHealth+50);
            ghost3.changeHealth(monsterHealth+50);
            ghost4.changeHealth(monsterHealth+50);
            ghost5.changeHealth(monsterHealth+50);
            ghosts = new Entity[]{ghost, ghost2,ghost3,ghost4,ghost5};
        }

        return ghosts;    //Should be changed to return an array of monsters instead of null
    }

    /**
     * Spawns a player entity in the game. The method uses the spawns ArrayList
     * to select a suitable location to spawn the player and removes the Point
     * from the spawns ArrayList. The method instantiates the Entity class and
     * assigns values for the health, position and type of Entity.
     * @return An Entity object representing the player in the game
     */
    public int health = 1000;
    private Entity spawnPlayer() {
        Point spawn = new Point(getSpawns().get(0));
        Entity player = new Entity(health, 1, 1, Entity.EntityType.PLAYER);
        return player;    //Should be changed to return an Entity (the player) instead of null
    }
    public Entity spawnPlayer2(){
        Entity player2 = new Entity(health,22,22, Entity.EntityType.PLAYER2);
        return player2;
    }

    /**
     * Handles the movement of the player when attempting to move left in the
     * game. This method is called by the DungeonInputHandler class when the
     * user has pressed the left arrow key on the keyboard. The method checks
     * whether the tile to the left of the player is empty for movement and if
     * it is updates the player object's X and Y locations with the new position.
     * If the tile to the left of the player is not empty the method will not
     * update the player position, but may make other changes to the game, such
     * as damaging a monster in the tile to the left, or breaking a wall etc.
     */
    public void movePlayerLeft() {
        int x = player.getX();
        int y = player.getY();
        if (player.getX() == x && player.getY() == y) {
            player.setPosition(x-1, y);
        }
        if (generateLevel()[x-1][y] == TileType.WALL){
            player.setPosition(x,y);
        }
        if (generateLevel()[x-1][y] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x-1][y] == TileType.LAVA) {
            hitPlayer();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player.setPosition(x-2,y);
        }
        if (generateLevel()[x-1][y] == TileType.HEART){
            healPlayer();
        }
        if (player2 != null){
        if (x-1 == player2.getX() && y == player2.getY()){
            player.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (monsters[i] != null){
                        if (x-1 == monsters[i].getX() && y == monsters[i].getY()){
                            player.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null){
                            if (x-1 == monsters[i+1].getX() && y == monsters[i+1].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (monsters[i+2] != null){
                            if (x-1 == monsters[i+2].getX() && y == monsters[i+2].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null){
                            if (x-1 == monsters[i+3].getX() && y == monsters[i+3].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null){
                            if (x-1 == monsters[i+4].getX() && y == monsters[i+4].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    hitMonster(monsters[i]);
                    if (depth >= 2){
                        hitMonster(monsters[i+1]);
                    }
                    if (depth >=3){
                        hitMonster(monsters[i+2]);
                    }
                    if (depth >= 4){
                        hitMonster(monsters[i+3]);
                    }
                    if (depth >= 5){
                        hitMonster(monsters[i+4]);
                    }
                }
            }
        }

    }

    /**
     * Handles the movement of the player when attempting to move right in the
     * game. This method is called by the DungeonInputHandler class when the
     * user has pressed the right arrow key on the keyboard. The method checks
     * whether the tile to the right of the player is empty for movement and if
     * it is updates the player object's X and Y locations with the new position.
     * If the tile to the right of the player is not empty the method will not
     * update the player position, but may make other changes to the game, such
     * as damaging a monster in the tile to the right, or breaking a wall etc.
     */
    public void movePlayerRight() {
        int x = player.getX();
        int y = player.getY();
        if (player.getX() == x && player.getY() == y) {
            player.setPosition(x + 1, y);
        }
        if (generateLevel()[x + 1][y] == TileType.WALL) {
            player.setPosition(x, y);
        }
        if (generateLevel()[x + 1][y] == TileType.STAIRS) {
            descendLevel();
        }
        if (generateLevel()[x+1][y] == TileType.LAVA) {
            hitPlayer();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player.setPosition(x+2,y);
        }
        if (generateLevel()[x+1][y] == TileType.HEART){
            healPlayer();
        }
        if (player2 != null){
        if (x+1 == player2.getX() && y == player2.getY()){
            player.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (monsters[i] != null){
                        if (x+1 == monsters[i].getX() && y == monsters[i].getY()){
                            player.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null){
                            if (x+1 == monsters[i+1].getX() && y == monsters[i+1].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (monsters[i+2] != null){
                            if (x+1 == monsters[i+2].getX() && y == monsters[i+2].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null){
                            if (x+1 == monsters[i+3].getX() && y == monsters[i+3].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null){
                            if (x+1 == monsters[i+4].getX() && y == monsters[i+4].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    hitMonster(monsters[i]);
                    if (depth >= 2){
                        hitMonster(monsters[i+1]);
                    }
                    if (depth >=3){
                        hitMonster(monsters[i+2]);
                    }
                    if (depth >= 4){
                        hitMonster(monsters[i+3]);
                    }
                    if (depth >= 5){
                        hitMonster(monsters[i+4]);
                    }
                }
            }
        }

    }

    /**
     * Handles the movement of the player when attempting to move up in the
     * game. This method is called by the DungeonInputHandler class when the
     * user has pressed the up arrow key on the keyboard. The method checks
     * whether the tile above the player is empty for movement and if
     * it is updates the player object's X and Y locations with the new position.
     * If the tile above the player is not empty the method will not
     * update the player position, but may make other changes to the game, such
     * as damaging a monster in the tile above the player, or breaking a wall etc.
     */
    public void movePlayerUp() {
        int x = player.getX();
        int y = player.getY();
        if(player.getX() == x && player.getY() == y){
            player.setPosition(x,y-1);
        }
        if (generateLevel()[x][y-1] == TileType.WALL){
            player.setPosition(x,y);
        }
        if (generateLevel()[x][y-1] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x][y-1] == TileType.LAVA) {
            hitPlayer();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player.setPosition(x,y-2);
        }
        if (generateLevel()[x][y-1] == TileType.HEART){
            healPlayer();
        }
        if (player2 != null){
        if (y-1 == player2.getY() && x == player2.getX()){
            player.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (monsters[i] != null){
                        if (x == monsters[i].getX() && y-1 == monsters[i].getY()){
                            player.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null){
                            if (x == monsters[i+1].getX() && y-1 == monsters[i+1].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (monsters[i+2] != null){
                            if (x == monsters[i+2].getX() && y-1 == monsters[i+2].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null){
                            if (x == monsters[i+3].getX() && y-1 == monsters[i+3].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null){
                            if (x == monsters[i+4].getX() && y-1 == monsters[i+4].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Handles the movement of the player when attempting to move right in the
     * game. This method is called by the DungeonInputHandler class when the
     * user has pressed the down arrow key on the keyboard. The method checks
     * whether the tile below the player is empty for movement and if
     * it is updates the player object's X and Y locations with the new position.
     * If the tile below the player is not empty the method will not
     * update the player position, but may make other changes to the game, such
     * as damaging a monster in the tile below the player, or breaking a wall etc.
     */
    public void movePlayerDown() {
        int x = player.getX();
        int y = player.getY();
        if(player.getX() == x && player.getY() == y){
            player.setPosition(x,y+1);
        }
        if (generateLevel()[x][y+1] == TileType.WALL){
            player.setPosition(x,y);
        }
        if (generateLevel()[x][y+1] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x][y+1] == TileType.LAVA) {
            hitPlayer();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player.setPosition(x,y+2);
        }
        if (generateLevel()[x][y+1] == TileType.HEART){
            healPlayer();
        }
        if (player2 != null){
        if (y+1 == player2.getY() && x == player2.getX()){
            player.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (monsters[i] != null){
                        if (x == monsters[i].getX() && y+1 == monsters[i].getY()){
                            player.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null){
                            if (x == monsters[i+1].getX() && y+1 == monsters[i+1].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (monsters[i+2] != null){
                            if (x == monsters[i+2].getX() && y+1 == monsters[i+2].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null){
                            if (x == monsters[i+3].getX() && y+1 == monsters[i+3].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null){
                            if (x == monsters[i+4].getX() && y+1 == monsters[i+4].getY()){
                                player.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }
    }

    public void movePlayerRandom(){
        int x = player.getX();
        int y = player.getY();
        if (generateLevel()[x][y] == TileType.PORTAL){
            Random r = new Random(123);
            player.setPosition((int)(Math.random()*23),(int)(Math.random()*23));
        }
    }

    public void movePlayer2Left(){ if (player2 != null){
        int x = player2.getX();
        int y = player2.getY();
        if (player2.getX() == x && player2.getY() == y) {
            player2.setPosition(x-1, y);
        }
        if (generateLevel()[x-1][y] == TileType.WALL){
            player2.setPosition(x,y);
        }
        if (generateLevel()[x-1][y] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x-1][y] == TileType.LAVA) {
            hitPlayer2();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player2.setPosition(x-2,y);
        }
        if (generateLevel()[x-1][y] == TileType.HEART){
            healPlayer2();
        }
        if (player2 != null){
        if (x-1 == player.getX() && y == player.getY()){
            player2.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (ghosts[i] != null){
                        if (x-1 == ghosts[i].getX() && y == ghosts[i].getY()){
                            player2.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (ghosts[i+1] != null){
                            if (x-1 == ghosts[i+1].getX() && y == ghosts[i+1].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (ghosts[i+2] != null){
                            if (x-1 == ghosts[i+2].getX() && y == ghosts[i+2].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (ghosts[i+3] != null){
                            if (x-1 == ghosts[i+3].getX() && y == ghosts[i+3].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (ghosts[i+4] != null){
                            if (x-1 == ghosts[i+4].getX() && y == ghosts[i+4].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    hitGhost(ghosts[i]);
                    if (depth >= 2){
                        hitGhost(ghosts[i+1]);
                    }
                    if (depth >=3){
                        hitGhost(ghosts[i+2]);
                    }
                    if (depth >= 4){
                        hitGhost(ghosts[i+3]);
                    }
                    if (depth >= 5){
                        hitGhost(ghosts[i+4]);
                    }
                }
            }
        }
    }}

    public void movePlayer2Right(){ if (player2 != null){
        int x = player2.getX();
        int y = player2.getY();
        if (player2.getX() == x && player2.getY() == y) {
            player2.setPosition(x + 1, y);
        }
        if (generateLevel()[x + 1][y] == TileType.WALL) {
            player2.setPosition(x, y);
        }
        if (generateLevel()[x + 1][y] == TileType.STAIRS) {
            descendLevel();
        }
        if (generateLevel()[x+1][y] == TileType.LAVA) {
            hitPlayer2();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player2.setPosition(x+2,y);
        }
        if (generateLevel()[x+1][y] == TileType.HEART){
            healPlayer2();
        }
        if (player2 != null){
        if (x+1 == player.getX() && y == player.getY()){
            player2.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (ghosts[i] != null){
                        if (x+1 == ghosts[i].getX() && y == ghosts[i].getY()){
                            player2.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (ghosts[i+1] != null){
                            if (x+1 == ghosts[i+1].getX() && y == ghosts[i+1].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (ghosts[i+2] != null){
                            if (x+1 == ghosts[i+2].getX() && y == ghosts[i+2].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (ghosts[i+3] != null){
                            if (x+1 == ghosts[i+3].getX() && y == ghosts[i+3].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (ghosts[i+4] != null){
                            if (x+1 == ghosts[i+4].getX() && y == ghosts[i+4].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    hitGhost(ghosts[i]);
                    if (depth >= 2){
                        hitGhost(ghosts[i+1]);
                    }
                    if (depth >=3){
                        hitGhost(ghosts[i+2]);
                    }
                    if (depth >= 4){
                        hitGhost(ghosts[i+3]);
                    }
                    if (depth >= 5){
                        hitGhost(ghosts[i+4]);
                    }
                }
            }
        }
    }}

    public void movePlayer2Up(){ if (player2 != null){
        int x = player2.getX();
        int y = player2.getY();
        if(player2.getX() == x && player2.getY() == y){
            player2.setPosition(x,y-1);
        }
        if (generateLevel()[x][y-1] == TileType.WALL){
            player2.setPosition(x,y);
        }
        if (generateLevel()[x][y-1] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x][y-1] == TileType.LAVA) {
            hitPlayer2();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player2.setPosition(x,y-2);
        }
        if (generateLevel()[x][y-1] == TileType.HEART){
            healPlayer2();
        }
        if (player2 != null){
        if (y-1 == player.getY() && x == player.getX()){
            player2.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (ghosts[i] != null){
                        if (x == ghosts[i].getX() && y-1 == ghosts[i].getY()){
                            player2.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (ghosts[i+1] != null){
                            if (x == ghosts[i+1].getX() && y-1 == ghosts[i+1].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (ghosts[i+2] != null){
                            if (x == ghosts[i+2].getX() && y-1 == ghosts[i+2].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (ghosts[i+3] != null){
                            if (x == ghosts[i+3].getX() && y-1 == ghosts[i+3].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (ghosts[i+4] != null){
                            if (x == ghosts[i+4].getX() && y-1 == ghosts[i+4].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }
    }}

    public void movePlayer2Down(){ if (player2 != null){
        int x = player2.getX();
        int y = player2.getY();
        if(player2.getX() == x && player2.getY() == y){
            player2.setPosition(x,y+1);
        }
        if (generateLevel()[x][y+1] == TileType.WALL){
            player2.setPosition(x,y);
        }
        if (generateLevel()[x][y+1] == TileType.STAIRS){
            descendLevel();
        }
        if (generateLevel()[x][y+1] == TileType.LAVA) {
            hitPlayer2();
        }
        if (generateLevel()[x][y] == TileType.PORTAL){
            player2.setPosition(x,y+2);
        }
        if (generateLevel()[x][y+1] == TileType.HEART){
            healPlayer2();
        }
        if (player2 != null){
        if (y+1 == player.getY() && x == player.getX()){
            player2.setPosition(x,y);
        }}
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 5; j++) {
                    if (ghosts[i] != null){
                        if (x == ghosts[i].getX() && y+1 == ghosts[i].getY()){
                            player2.setPosition(x,y);
                        }
                    }
                    if (depth >= 2){
                        if (ghosts[i+1] != null){
                            if (x == ghosts[i+1].getX() && y+1 == ghosts[i+1].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >=3){
                        if (ghosts[i+2] != null){
                            if (x == ghosts[i+2].getX() && y+1 == ghosts[i+2].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 4){
                        if (ghosts[i+3] != null){
                            if (x == ghosts[i+3].getX() && y+1 == ghosts[i+3].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                    if (depth >= 5){
                        if (ghosts[i+4] != null){
                            if (x == ghosts[i+4].getX() && y+1 == ghosts[i+4].getY()){
                                player2.setPosition(x,y);
                            }
                        }
                    }
                }
            }
        }
    }}

    public void movePlayer2Random(){ if (player2 != null){
        int x = player2.getX();
        int y = player2.getY();
        if (generateLevel()[x][y] == TileType.PORTAL){
            Random r = new Random(123);
            player2.setPosition((int)(Math.random()*23),(int)(Math.random()*23));
        }
    }}

    /**
     * Reduces a monster's health in response to the player attempting to move
     * into the same square as the monster (attacking the monster).
     * @param m The Entity which is the monster that the player is attacking
     */

    private void hitMonster(Entity m) {
        int x = player.getX();
        int y = player.getY();
        if (m != null) {
            if (x+1 == m.getX() && y == m.getY() || x-1 == m.getX() && y == m.getY()) {
                m.changeHealth(-20);
            }
        }
    }

    private void hitGhost(Entity g){
        int x = player2.getX();
        int y = player2.getY();
        if (g != null){
            if (x+1 == g.getX() && y == g.getY() || x-1 == g.getX() && y == g.getY()) {
                g.changeHealth(-20);
            }
        }
    }

    /**
     * Moves all monsters on the current level. The method processes all non-null
     * elements in the monsters array and calls the moveMonster method for each one.
     */
    private void moveMonsters() {

        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 1; j++) {
                    if (monsters[i] != null) {
                        moveMonster(monsters[i]);
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null) {
                            moveMonster(monsters[i + 1]);
                        }
                    }
                    if (depth >= 3){
                        if (monsters[i+2] != null) {
                            moveMonster(monsters[i + 2]);
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null) {
                            moveMonster(monsters[i + 3]);
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null) {
                            moveMonster(monsters[i + 4]);
                        }
                    }
                }
            }
        }

    }

    private void moveGhosts() {
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i) {
                for (int j = 0; j < 1; j++) {
                    if (ghosts[i] != null && player2 != null) {
                        moveGhost(ghosts[i]);
                    }
                    if (depth >= 2) {
                        if (ghosts[i + 1] != null) {
                            moveGhost(ghosts[i + 1]);
                        }
                    }
                    if (depth >= 3) {
                        if (ghosts[i + 2] != null) {
                            moveGhost(ghosts[i + 2]);
                        }
                    }
                    if (depth >= 4) {
                        if (ghosts[i + 3] != null) {
                            moveGhost(ghosts[i + 3]);
                        }
                    }
                    if (depth >= 5) {
                        if (ghosts[i + 4] != null) {
                            moveGhost(ghosts[i + 4]);
                        }
                    }
                }
            }
        }
    }

    /**
     * Moves a specific monster in the game. The method updates the X and Y
     * attributes of the monster Entity to reflect its new position.
     * @param m The Entity (monster) that needs to be moved
     */
    private void moveMonster(Entity m) {
        int x = m.getX();
        int y = m.getY();
        if (x+1 != player.getX()){
            if (generateLevel()[x+1][y] == TileType.FLOOR){
                if (player.getX() > m.getX()){
                    m.setPosition(x+1,y);
                }
            }}
        if (x-1 != player.getX()){
            if (generateLevel()[x-1][y] == TileType.FLOOR){
                if (player.getX() < m.getX()){
                    m.setPosition(x-1,y);
                }
            }}
        //if (y+1 != player.getY()){
        if (generateLevel()[x][y+1] == TileType.FLOOR){
            if (player.getY() > m.getY()) {
                m.setPosition(x, y + 1);
            }
        }//}
        //if (y-1 != player.getY()){
        if (generateLevel()[x][y-1] == TileType.FLOOR){
            if (player.getY() < m.getY()){
                m.setPosition(x, y-1);
            }
        }//}
        if ((x+1 == player.getX() && y == player.getY()) || (x-1 == player.getX() && y == player.getY())){
            hitPlayer();
            if (player.getHealth() < 20){
                System.out.println("Careful your dying. ");
            }
            if (player.getHealth() < 10){
                System.out.println("Game Over!!!");
            }
        }
        if ((x == player.getX() && y-1 == player.getY()) || (x == player.getX() && y+1 == player.getY())){
            hitPlayer();
            if (player.getHealth() < 20){
                System.out.println("Careful your dying. ");
            }
            if (player.getHealth() < 10){
                System.out.println("Game Over!!!");
            }
        }

        if (m.getHealth() <1) {
            cleanDeadMonsters();
        }
    }

    private void moveGhost(Entity g) {
        int x = g.getX();
        int y = g.getY();
        if (x+1 != player2.getX()){
            if (generateLevel()[x+1][y] == TileType.FLOOR){
                if (player2.getX() > g.getX()){
                    g.setPosition(x+1,y);
                }
            }}
        if (x-1 != player2.getX()){
            if (generateLevel()[x-1][y] == TileType.FLOOR){
                if (player2.getX() < g.getX()){
                    g.setPosition(x-1,y);
                }
            }}
        //if (y+1 != player.getY()){
        if (generateLevel()[x][y+1] == TileType.FLOOR){
            if (player2.getY() > g.getY()) {
                g.setPosition(x, y + 1);
            }
        }//}
        //if (y-1 != player.getY()){
        if (generateLevel()[x][y-1] == TileType.FLOOR){
            if (player2.getY() < g.getY()){
                g.setPosition(x, y-1);
            }
        }//}
        if ((x+1 == player2.getX() && y == player2.getY()) || (x-1 == player2.getX() && y == player2.getY())){
            hitPlayer2();
            if (player2.getHealth() < 20){
                System.out.println("Careful your dying. ");
            }
            if (player.getHealth() < 10){
                System.out.println("Game Over!!!");
            }
        }
        if ((x == player2.getX() && y-1 == player2.getY()) || (x == player2.getX() && y+1 == player2.getY())){
            hitPlayer2();
            if (player2.getHealth() < 20){
                System.out.println("Careful your dying. ");
            }
            if (player2.getHealth() < 10){
                System.out.println("Game Over!!!");
            }
        }

        if (g.getHealth() <1) {
            cleanDeadGhosts();
        }
    }

    /**
     * Reduces the health of the player when hit by a monster - a monster next
     * to the player can attack it instead of moving and should call this method
     * to reduce the player's health
     */
    private void hitPlayer() {
        player.changeHealth(-10);
    }
    private void hitPlayer2(){
        player2.changeHealth(-10);
    }
    private void healPlayer(){
        player.changeHealth(+10);
    }
    private void healPlayer2(){
        player2.changeHealth(+10);
    }

    /**
     * Processes the monsters array to find any Entity in the array with 0 or
     * less health. Any Entity in the array with 0 or less health should be
     * set to null; when drawing or moving monsters the null elements in the
     * monsters array are skipped.
     */
    Scores s = new Scores();
    private void cleanDeadMonsters() {
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i){
                for (int j = 0; j < 1; j++) {
                    if (monsters[i] != null) {
                        if (monsters[i].getHealth() < 1) {
                            Array.set(monsters, i, null);
                            s.score = s.score+10;
                            gui.canvas.scoreOne.setText("Score: " +Integer.toString(s.score));
                            l.scoreOne.setText("Score: " +Integer.toString(s.score));
                        }
                    }
                    if (depth >= 2){
                        if (monsters[i+1] != null) {
                            if (monsters[i+1].getHealth() < 1) {
                                Array.set(monsters, i+1, null);
                                s.score = s.score+10;
                                gui.canvas.scoreOne.setText("Score: " +Integer.toString(s.score));
                            }
                        }
                    }
                    if (depth >= 3){
                        if (monsters[i+2] != null) {
                            if (monsters[i+2].getHealth() < 1) {
                                Array.set(monsters, i+2, null);
                                s.score = s.score+10;
                                gui.canvas.scoreOne.setText("Score: " +Integer.toString(s.score));
                            }
                        }
                    }
                    if (depth >= 4){
                        if (monsters[i+3] != null) {
                            if (monsters[i+3].getHealth() < 1) {
                                Array.set(monsters, i+3, null);
                                s.score = s.score+10;
                                gui.canvas.scoreOne.setText("Score: " +Integer.toString(s.score));
                            }
                        }
                    }
                    if (depth >= 5){
                        if (monsters[i+4] != null) {
                            if (monsters[i+4].getHealth() < 1) {
                                Array.set(monsters, i+4, null);
                                s.score = s.score+10;
                                gui.canvas.scoreOne.setText("Score: " +Integer.toString(s.score));
                            }
                        }
                    }
                }
            }
        }
    }
    private void cleanDeadGhosts() {
    if (player2 != null) {
        for (int i = 0; i < depth; i++) {
            if (depth == depth + i) {
                for (int j = 0; j < 1; j++) {
                    if (ghosts[i] != null) {
                        if (ghosts[i].getHealth() < 1) {
                            Array.set(ghosts, i, null);
                            s.score2 = s.score2+10;
                            gui.canvas.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                        }
                    }
                    if (depth >= 2) {
                        if (ghosts[i + 1] != null) {
                            if (ghosts[i + 1].getHealth() < 1) {
                                Array.set(ghosts, i + 1, null);
                                s.score2 = s.score2+10;
                                gui.canvas.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                            }
                        }
                    }
                    if (depth >= 3) {
                        if (ghosts[i + 2] != null) {
                            if (ghosts[i + 2].getHealth() < 1) {
                                Array.set(ghosts, i + 2, null);
                                s.score2 = s.score2+10;
                                gui.canvas.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                            }
                        }
                    }
                    if (depth >= 4) {
                        if (ghosts[i + 3] != null) {
                            if (ghosts[i + 3].getHealth() < 1) {
                                Array.set(ghosts, i + 3, null);
                                s.score2 = s.score2+10;
                                gui.canvas.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                            }
                        }
                    }
                    if (depth >= 5) {
                        if (ghosts[i + 4] != null) {
                            if (ghosts[i + 4].getHealth() < 1) {
                                Array.set(ghosts, i + 4, null);
                                s.score2 = s.score2+10;
                                gui.canvas.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                            }
                        }
                    }
                }
            }
        }
    }
    }

    /**
     * Called in response to the player moving into a Stair tile in the game.
     * The method increases the dungeon depth, generates a new level by calling
     * the generateLevel method, fills the spawns ArrayList with suitable spawn
     * locations and spawns monsters. Finally it places the player in the new
     * level by calling the placePlayer() method. Note that a new player object
     * should not be created here unless the health of the player should be reset.
     */
    private void descendLevel() {
        depth = depth + 1;
        placePlayer();
        placePlayer2();

        tiles = generateLevel();
        spawns = getSpawns();
        monsters = spawnMonsters();
        if (player2 != null) {
            ghosts = spawnGhosts();
        }
        gui.updateDisplay(tiles, player, monsters,player2,ghosts);
    }

    /**
     * Places the player in a dungeon level by choosing a spawn location from the
     * spawns ArrayList, removing the spawn position as it is used. The method sets
     * the players position in the level by calling its setPosition method with the
     * x and y values of the Point taken from the spawns ArrayList.
     */
    private void  placePlayer() {
        //Point spawn = new Point(getSpawns().get(0));
        player.setPosition(1, 1);
    }
    private void placePlayer2(){
        if (player2 != null) {
            player2.setPosition(22, 22);
        }
    }

    /**
     * Performs a single turn of the game when the user presses a key on the
     * keyboard. The method cleans dead monsters, moves any monsters still alive
     * and then checks if the player is dead, exiting the game or resetting it
     * after an appropriate output to the user is given. It checks if the player
     * moved into a stair tile and calls the descendLevel method if it does.
     * Finally it requests the GUI to redraw the game level by passing it the
     * tiles, player and monsters for the current level.
     */
    Labels l = new Labels();
    public void doTurn() {
        //Entity m = new Entity(20,10,10, Entity.EntityType.MONSTER);
        cleanDeadMonsters();
        moveMonsters();
        if (player2 != null) {
            moveGhosts();
        }
        cleanDeadGhosts();
        if (player != null) {       //checks a player object exists
            if (player.getHealth() < 1) {
                if (s.score == s.score){
                    End end = new End();
                    if (s.score > s.score2){
                        end.playerOneWon.setVisible(true);
                    }
                    if (s.score2 > s.score){
                        end.playerTwoWon.setVisible(true);
                    }
                    end.scoreOne.setText("Score: " +Integer.toString(s.score));
                    end.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                }
                gui.setVisible(false);
                //System.exit(0);     //exits the game when player is dead
            }
            if (tiles[player.getX()][player.getY()] == TileType.STAIRS) {
                descendLevel();     //moves to next level if the player is on Stairs
            }
        }
        if (player2 != null){
            if (player2.getHealth() < 1) {
                if (s.score2 == s.score2){
                    End end = new End();
                    if (s.score > s.score2){
                        end.playerOneWon.setVisible(true);
                    }
                    if (s.score2 > s.score){
                        end.playerTwoWon.setVisible(true);
                    }
                    end.scoreOne.setText("Score: " +Integer.toString(s.score));
                    end.scoreTwo.setText("Score: " +Integer.toString(s.score2));
                }
                gui.setVisible(false);
                //System.exit(0);
            }
        }
        gui.updateDisplay(tiles, player, monsters,player2,ghosts);     //updates GUI
    }

    /**
     * Starts a game. This method generates a level, finds spawn positions in
     * the level, spawns monsters and the player and then requests the GUI to
     * update the level on screen using the information on tiles, player and
     * monsters.
     */

    public void startGame() {
        if (b.button3.isEnabled()){
            //depth = 20;
        }
        tiles = generateLevel();
        spawns = getSpawns();
        monsters = spawnMonsters();
        player = spawnPlayer();
        gui.updateDisplay(tiles, player, monsters,player2,ghosts);
    }
    public void startGame2(){
        tiles = generateLevel();
        spawns = getSpawns();
        monsters = spawnMonsters();
        ghosts = spawnGhosts();
        player = spawnPlayer();
        player2 = spawnPlayer2();
        gui.updateDisplay(tiles, player, monsters,player2,ghosts);
    }
}