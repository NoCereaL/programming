package com.simon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Calc {

    private JFrame frame;
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JLabel title;
    private JTextField text;

    private JButton one;
    private JButton two;
    private JButton three;
    private JButton four;
    private JButton five;
    private JButton six;
    private JButton seven;
    private JButton eight;
    private JButton nine;
    private JButton zero;

    private JButton plus;
    private JButton minus;
    private JButton multiply;
    private JButton divide;
    private JButton equal;

    public Calc(){
        frame = new JFrame("Calculator");

        title = new JLabel("Simon's Calculator");

        text = new JTextField("");
        text.setBounds(190,230,200,30);

        one = new JButton("1");
        one.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 1);
                }
            }
        });

        two = new JButton("2");
        two.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 2);
                }
            }
        });

        three = new JButton("3");
        three.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 3);
                }
            }
        });

        four = new JButton("4");
        four.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 4);
                }
            }
        });

        five = new JButton("5");
        five.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 5);
                }
            }
        });

        six = new JButton("6");
        six.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 6);
                }
            }
        });

        seven = new JButton("7");
        seven.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 7);
                }
            }
        });

        eight = new JButton("8");
        eight.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 8);
                }
            }
        });

        nine = new JButton("9");
        nine.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 9);
                }
            }
        });

        zero = new JButton("0");
        zero.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + 0);
                }
            }
        });



        plus = new JButton("+");
        plus.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (plus.isEnabled()){
                    text.setText(text.getText() + "+");
                }
            }
        });

        minus = new JButton("-");
        minus.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + "-");
                }
            }
        });

        multiply = new JButton("x");
        multiply.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + "x");
                }
            }
        });

        divide = new JButton("÷");
        divide.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isEnabled()){
                    text.setText(text.getText() + "÷");
                }
            }
        });

        equal = new JButton("=");
        equal.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (text.getText().length() == 3){
                    if (text.getText().substring(1,2).equals("+")) {
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) + Integer.parseInt(text.getText().substring(2, 3));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("-")) {
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) - Integer.parseInt(text.getText().substring(2, 3));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("x")) {
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) * Integer.parseInt(text.getText().substring(2, 3));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("÷")) {
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) / Integer.parseInt(text.getText().substring(2, 3));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                }

                if (text.getText().length() == 5){
                    if (text.getText().substring(2,3).equals("+")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) + Integer.parseInt(text.getText().substring(3, 5));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("-")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) - Integer.parseInt(text.getText().substring(3, 5));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("*")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) * Integer.parseInt(text.getText().substring(3, 5));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("÷")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) / Integer.parseInt(text.getText().substring(3, 5));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                }

                if (text.getText().length() == 4){
                    if (text.getText().substring(1,2).equals("+")){
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) + Integer.parseInt(text.getText().substring(2, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("-")){
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) - Integer.parseInt(text.getText().substring(2, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("x")){
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) * Integer.parseInt(text.getText().substring(2, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(1,2).equals("÷")){
                        int ans = Integer.parseInt(text.getText().substring(0, 1)) / Integer.parseInt(text.getText().substring(2, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    else if (text.getText().substring(2,3).equals("+")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) + Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    else if (text.getText().substring(2,3).equals("-")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) - Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    else if (text.getText().substring(2,3).equals("x")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) * Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    else if (text.getText().substring(2,3).equals("÷")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) / Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                }

               /* else if (text.getText().length() == 4){
                    if (text.getText().substring(2,3).equals("+")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) + Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("-")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) - Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("*")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) * Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                    if (text.getText().substring(2,3).equals("÷")){
                        int ans = Integer.parseInt(text.getText().substring(0, 2)) / Integer.parseInt(text.getText().substring(3, 4));
                        String answer = Integer.toString(ans);
                        text.setText(answer);
                        System.out.println(ans);
                    }
                }*/


                if (text.getText().substring(1,2).equals("-")){
                    int ans = Integer.parseInt(text.getText().substring(0,1)) - Integer.parseInt(text.getText().substring(2,3));
                    String answer = Integer.toString(ans);
                    text.setText(answer);
                    System.out.println(ans);
                }
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();

        panel2 = new JPanel();
        panel2.add(title);

        panel = new JPanel();
        panel.setLayout(new GridBagLayout());

        gbc.insets = new Insets(5,5,5,5);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(one,gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(two, gbc);
        gbc.gridx  = 2;
        gbc.gridy = 1;
        panel.add(three, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(four, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(five, gbc);
        gbc.gridx = 2;
        gbc.gridy = 2;
        panel.add(six, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(seven, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(eight, gbc);
        gbc.gridx = 2;
        gbc.gridy = 3;
        panel.add(nine, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(zero, gbc);
        gbc.gridx = 2;
        gbc.gridy = 4;
        panel.add(equal, gbc);

        gbc.gridx = 4;
        gbc.gridy = 1;
        panel.add(plus, gbc);
        gbc.gridx = 4;
        gbc.gridy = 2;
        panel.add(minus, gbc);
        gbc.gridx = 4;
        gbc.gridy = 3;
        panel.add(multiply, gbc);
        gbc.gridx = 4;
        gbc.gridy = 4;
        panel.add(divide, gbc);

        frame.add(text);
        frame.add(panel2, BorderLayout.NORTH);
        frame.add(panel, BorderLayout.CENTER);
        frame.setSize(600,700);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Calc();
    }
}
